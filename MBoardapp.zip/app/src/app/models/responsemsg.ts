export class DisplayMsg {
    response: string;
    error: string;
    message: string;
    result: any;
}