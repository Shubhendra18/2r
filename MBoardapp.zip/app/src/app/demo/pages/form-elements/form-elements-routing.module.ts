import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'Inbox',
        loadChildren: './inbox/inbox.module#InboxModule'
      },
      {
        path: 'Compose',
        loadChildren: './compose/compose.module#ComposeModule'
      },
      {
        path: 'Sent',
        loadChildren: './send/send.module#SendModule'
      },
      {
        path: 'Important',
        loadChildren: './important/important.module#ImportantModule'
      },
      {
        path: 'Draft',
        loadChildren: './draft/draft.module#DraftModule'
      },
      {
        path: 'Archive',
        loadChildren: './archive/archive.module#ArchiveModule'
      },
      {
        path: 'Trash',
        loadChildren: './trash/trash.module#TrashModule'
      },
      {
        path: 'details/:ml/:ms',
        loadChildren: './details/details.module#DetailsModule'
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormElementsRoutingModule { }
