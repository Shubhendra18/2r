import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { InboxRoutingModule } from './inbox-routing.module';
import { InboxComponent } from './inbox.component';


import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        InboxRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule,
    ],
    declarations: [InboxComponent]
})
export class InboxModule { }
