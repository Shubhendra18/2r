import { TestBed } from '@angular/core/testing';

import { SidebarupdateService } from './sidebarupdate.service';

describe('SidebarupdateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SidebarupdateService = TestBed.get(SidebarupdateService);
    expect(service).toBeTruthy();
  });
});
