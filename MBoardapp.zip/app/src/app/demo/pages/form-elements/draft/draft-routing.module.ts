import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DraftComponent } from './draft.component';

const routes: Routes = [
    {
        path: '',
        component: DraftComponent
    },
    {
        path: ':mailid',
        loadChildren: () => import('../draft-compose/draft-compose.module').then(m =>
            m.DraftComposeModule)
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DraftRoutingModule { }
