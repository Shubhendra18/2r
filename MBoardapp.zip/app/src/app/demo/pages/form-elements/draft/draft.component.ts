import { Component, OnInit, OnDestroy } from '@angular/core';

import { ToastrService } from 'ngx-toastr';
import * as CryptoJS from 'crypto-js';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-draft',
  templateUrl: './draft.component.html',
  styleUrls: ['./draft.component.scss']
})
export class DraftComponent implements OnInit, OnDestroy {
  allmails: any = [];
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  dtOptions: any = {};
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromDraft(this.Rid).subscribe(k => {
      this.allmails = k;
      this.dtTrigger.next();
    });
    this.dtOptions = this.service.getDataTable();

  }
  trackByFn(index: number, item) {
    return index;
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
