import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { DraftRoutingModule } from './draft-routing.module';
import { DraftComponent } from './draft.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        DraftRoutingModule,
        SharedModule,
        DataTablesModule
    ],
    declarations: [DraftComponent]
})
export class DraftModule { }
