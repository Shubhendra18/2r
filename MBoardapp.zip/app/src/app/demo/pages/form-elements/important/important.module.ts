import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { ImportantRoutingModule } from './important-routing.module';
import { ImportantComponent } from './important.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        ImportantRoutingModule,
        SharedModule,
        DataTablesModule
    ],
    declarations: [ImportantComponent]
})
export class ImportantModule { }
