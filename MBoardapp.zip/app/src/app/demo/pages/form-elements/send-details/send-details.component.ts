import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-send-details',
  templateUrl: './send-details.component.html',
  styleUrls: ['./send-details.component.scss']
})
export class SendDetailsComponent implements OnInit {
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  maildetails: any = {};
  attachments: any = [];
  attachmentcount: number = 0;
  constructor(private service: MboardserviceService, private route: ActivatedRoute, private _location: Location, private titleService: Title) { }

  ngOnInit() {
    this.titleService.setTitle('Details - Mboard');
    this.route.paramMap.subscribe(params => {
      var sendMailDes = { "userId": this.Rid, "messageid": params.get('messageid') };
      this.service.GetSentMailDetails(sendMailDes).subscribe(k => {
        this.maildetails = k;
      })
      var mailDes = { "mailId": params.get('amessageid'), "rid": this.Rid };
      this.service.getSentattachments(mailDes).subscribe(k => {
        this.attachments = k;
        this.attachmentcount = this.attachments.length;
      })
    });
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  Download(attachment) {
    this.service.DownloadAttachments(attachment).subscribe(k => {
    });
  }
  backClicked() {
    this._location.back();
  }
}
