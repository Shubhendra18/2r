import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { SendDetailsComponent } from './send-details.component';
import { SendDetailsRoutingModule } from './send-details-routing.module';

@NgModule({
    imports: [
        CommonModule,
        SendDetailsRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule
    ],
    declarations: [SendDetailsComponent]
})
export class SendDetailsModule { }
