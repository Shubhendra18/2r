import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DraftComposeRoutingModule } from './draft-compose-routing.module';
import { DraftComposeComponent } from './draft-compose.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    DraftComposeRoutingModule,
    SharedModule,
    NgxSummernoteModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule.forRoot(),
  ],
  declarations: [DraftComposeComponent]
})
export class DraftComposeModule { }
