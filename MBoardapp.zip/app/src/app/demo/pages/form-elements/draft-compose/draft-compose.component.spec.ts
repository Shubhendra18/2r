import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DraftComposeComponent } from './draft-compose.component';

describe('BasicElementsComponent', () => {
  let component: DraftComposeComponent;
  let fixture: ComponentFixture<DraftComposeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DraftComposeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DraftComposeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
