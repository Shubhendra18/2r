import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { ComposeRoutingModule } from './compose-routing.module';
import { ComposeComponent } from './compose.component';
import { SelectModule } from 'ng-select';
import { NgxSummernoteModule } from 'ngx-summernote';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@NgModule({
    imports: [
        CommonModule,
        ComposeRoutingModule,
        SharedModule,
        NgbDropdownModule,
        SelectModule,
        NgxSummernoteModule,
        ReactiveFormsModule,
        NgMultiSelectDropDownModule.forRoot(),

    ],
    declarations: [ComposeComponent]
})
export class ComposeModule { }
