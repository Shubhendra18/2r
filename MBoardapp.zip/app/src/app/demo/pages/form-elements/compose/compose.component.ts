import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { MboardserviceService } from 'src/app/mboardservice.service';
@Component({
  selector: 'app-compose',
  templateUrl: './compose.component.html',
  styleUrls: ['./compose.component.scss']
})
export class ComposeComponent implements OnInit {
  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  public users: any = [];

  decryptnew = localStorage.getItem("Token").toString();
  Sid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  dropdownList: any = [];
  selectedItems = [];
  dropdownSettings = {};
  rId: any[] = [];
  current: any = [];
  files: any[] = [];



  constructor(private service: MboardserviceService, ) { }

  ngOnInit() {
    // $.getScript('assets/js/nifty.min.js');
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });


    this.dropdownSettings = {
      singleSelection: false,
      data: 'dropdownList',
      idField: 'userId',
      textField: 'officeName',
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

  }
  config = {
    placeholder: 'Type Your Message Here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times'],
    disableDragAndDrop: true,
    tabDisable: false

  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.current = k;
      let userid = this.Sid;
      this.dropdownList = this.current.filter(function (x) { return x['userId'] != userid });
    });
  }

  saveasdraft(mailBox) {
    this.service.MoveToDraft(mailBox.value.Priority, mailBox.value.SMS, mailBox.value.Subject, mailBox.value.Message, this.Sid).subscribe((data: any) => {
      if (data == "success") {
        this.files.length = 0;
        this.rId.length = 0;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
      };
    });

  }
  //#region File
  onFileDropped($event) {
    this.prepareFilesList($event);
  }
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }
  deleteFile(index: number) {
    this.files.splice(index, 1);
  }
  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      this.service.FileHandle(item).subscribe(
        data => {
          item.progress = 0;
          this.files.push(item);
        }, (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              icon: 'warning',
              title: err.error.message,
              text: "Warning",
            })
          };
        }
      );
    }
    this.uploadFilesSimulator(0);
  }
  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  //#endregion
  profileUpdate(mailBox) {
    this.service.Attachmentsfiles(this.files, mailBox.value.Priority, mailBox.value.SMS, mailBox.value.Subject, mailBox.value.Message, this.Sid, mailBox.value.Rid).subscribe((data: any) => {
      if (data == "success") {
        this.files.length = 0;
        this.rId.length = 0;
        this.dropdownList = [];

      }
    }, (err: HttpErrorResponse) => {
      if (err.status == 400) {
      };
    });;
  }
  reset() {
    this.files.length = 0;
    this.rId.length = 0;
    this.dropdownList = [];
  }
}
