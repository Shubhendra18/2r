import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SidebarupdateService {
  //private baseUrl = "http://demo.otpl.in/mbapi"
  //public buttonClick = new Subject();
  private baseUrl = "http://localhost:4876";
  //private baseUrl = "http://localhost:61658";


  constructor(private http: HttpClient) { }

  getbaseurl() {
    return this.baseUrl;
  }

  allMailFromDraft(Rid) {
    return this.http.get(this.baseUrl + "/api/FromDraft/" + Rid);
  }

  getmail(Rid) {
    return this.http.get(this.baseUrl + "/api/InboxMail/" + Rid);
  }

  allMailFromTrash(Rid) {
    return this.http.get(this.baseUrl + "/api/FromTrash/" + Rid);
  }

  allMailFromArchive(Rid) {
    return this.http.get(this.baseUrl + "/api/FromArchive/" + Rid);
  }

  allMailFromImportant(Rid) {
    return this.http.get(this.baseUrl + "/api/AllMailFromImportant/" + Rid);
  }

  allMailFromSent(Sid) {
    return this.http.get(this.baseUrl + "/api/SentMails/" + Sid);
  }
}
