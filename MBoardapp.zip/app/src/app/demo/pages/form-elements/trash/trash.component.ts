import { Component, OnInit, OnDestroy } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import * as CryptoJS from 'crypto-js';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.scss']
})
export class TrashComponent implements OnInit, OnDestroy {
  allmails: any = [];
  SelectedIDs: any = [];
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  baseurl: any = "";
  dtOptions: any = {};
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromTrash(this.Rid).subscribe(k => {
      this.allmails = k;
      this.dtTrigger.next();
    });
    this.dtOptions = this.service.getDataTable();

  }
  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 2 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('', 'Message Moved to Inbox Successfully');
        this.service.allMailFromTrash(this.Rid).subscribe(k => {
          this.allmails = k;
        });
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
