import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { TrashRoutingModule } from './trash-routing.module';
import { TrashComponent } from './trash.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        TrashRoutingModule,
        SharedModule,
        DataTablesModule
    ],
    declarations: [TrashComponent]
})
export class TrashModule { }
