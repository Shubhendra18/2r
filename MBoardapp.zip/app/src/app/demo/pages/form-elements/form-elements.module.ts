import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormElementsRoutingModule } from './form-elements-routing.module';
import { SharedModule } from '../../../theme/shared/shared.module';

import { AvatarModule } from 'ngx-avatar';
import { DndDirective } from 'src/app/resources/dnd.directive';
const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];
@NgModule({
  imports: [
    CommonModule,
    FormElementsRoutingModule,
    SharedModule,
    AvatarModule.forRoot({
      colors: avatarColors
    }),
  ],
  declarations: [DndDirective]
})
export class FormElementsModule { }
