import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { DetailsRoutingModule } from './details-routing.module';
import { DetailsComponent } from './details.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { NgbAccordionModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    imports: [
        CommonModule,
        DetailsRoutingModule,
        SharedModule,
        NgbDropdownModule,
        NgxSummernoteModule,
        NgbCollapseModule,
        NgbAccordionModule
    ],
    declarations: [DetailsComponent]
})
export class DetailsModule { }
