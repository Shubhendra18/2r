import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SendComponent } from './send.component';

const routes: Routes = [
    {
        path: '',
        component: SendComponent
    },
    {
        path: ':messageid',
        loadChildren: () => import('../send-details/send-details.module').then(m =>
            m.SendDetailsModule)
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SendRoutingModule { }
