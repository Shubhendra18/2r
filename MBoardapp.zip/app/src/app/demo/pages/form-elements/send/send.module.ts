import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SendRoutingModule } from './send-routing.module';
import { SendComponent } from './send.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        SendRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule
    ],
    declarations: [SendComponent]
})
export class SendModule { }
