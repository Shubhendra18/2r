import { Component, OnInit, OnDestroy } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-send',
  templateUrl: './send.component.html',
  styleUrls: ['./send.component.scss']
})
export class SendComponent implements OnInit, OnDestroy {
  allmails: any = [];
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  dtOptions: any = {};
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.allmails = k;
      this.dtTrigger.next();
    });
    this.dtOptions = this.service.getDataTable();

  }
  Refresh() {
    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
