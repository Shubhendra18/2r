import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signout',
  templateUrl: './signout.component.html',
  styleUrls: ['./signout.component.scss']
})
export class SignoutComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit() {
    localStorage.removeItem('Token');
    localStorage.removeItem('Dep');
    localStorage.removeItem('Roll');
    this.route.navigate(['/auth/signout']);
  }

}
