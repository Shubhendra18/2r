// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';

// @Component({
//     selector: 'app-auth-signin',
//     templateUrl: './auth-signin.component.html',
//     styleUrls: ['./auth-signin.component.scss']
// })
// export class AuthSigninComponent implements OnInit {
//     private changenav: any;
//     constructor(private router: Router) { }

//     ngOnInit() {
//     }
//     login() {
//         localStorage.setItem("Roll", "1");
//         this.router.navigate(['/u/Compose']);
//     }
// }

import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from 'ngx-spinner';

import { MboardserviceService } from 'src/app/mboardservice.service';
import { DisplayMsg } from 'src/app/models/responsemsg';

@Component({
  selector: 'app-auth-signin',
  templateUrl: './auth-signin.component.html',
  styleUrls: ['./auth-signin.component.scss']
})
export class AuthSigninComponent implements OnInit {
  officeName: any;
  PasswordData: any;
  CaptchaData: any;

  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  users: any = [];
  captchaKey: string = "";
  captchaerror = false;
  encrpt: string;
  plainText: string;
  baseurl: any = "";
  captchapic: any;
  public loading = false;

  dptid: any;
  dptData: any = {};
  constructor(private service: MboardserviceService, private router: Router, private route: ActivatedRoute, private SpinnerService: NgxSpinnerService) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha";
  }

  ngOnInit() {
    this.GetData();
  }
  GetData() {
    this.SpinnerService.show();
    this.route.paramMap.subscribe(params => {
      this.dptid = params.get('dptid');
      this.service.Departmentinfo(this.dptid).subscribe(k => {
        this.dptData = k['result'];
        console.log(this.dptData.departmentId)
        localStorage.setItem('Dep', this.dptData.departmentId);
        this.SpinnerService.hide();
        this.service.GroupMaster().subscribe(k => {
          this.groupData = k
        });
      });
      // this.service.DBConfigData(this.dptid).subscribe(k => {});
      
    });
  }
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha?=" + Math.random();
  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.users = k;
    });
  }

  login(loginData) {
    this.loading = true;
    this.service.AdminLogin(loginData.value).subscribe((data: DisplayMsg) => {
      this.plainText = data.result['userId'].toString();
      console.log(this.plainText)
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "at").toString();
      localStorage.setItem('Token', this.encrpt);
     // localStorage.setItem('Dep', this.dptid);
      this.loading = false;
      this.router.navigate(['/u/Inbox']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
        this.refreshcaptcha();
        loginData.value.Password = "";
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}