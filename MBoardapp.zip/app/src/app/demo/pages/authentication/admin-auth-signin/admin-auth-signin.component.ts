// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';

// @Component({
//     selector: 'app-auth-signin',
//     templateUrl: './auth-signin.component.html',
//     styleUrls: ['./auth-signin.component.scss']
// })
// export class AuthSigninComponent implements OnInit {
//     private changenav: any;
//     constructor(private router: Router) { }

//     ngOnInit() {
//     }
//     login() {
//         localStorage.setItem("Roll", "1");
//         this.router.navigate(['/u/Compose']);
//     }
// }

import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from 'ngx-spinner';

import { MboardserviceService } from 'src/app/mboardservice.service';
import { DisplayMsg } from 'src/app/models/responsemsg';

@Component({
  selector: 'app-admin-auth-signin',
  templateUrl: './admin-auth-signin.component.html',
  styleUrls: ['./admin-auth-signin.component.scss']
})
export class AdminAuthSigninComponent implements OnInit {
  captchaKey: string = "";
  captchaerror = false;
  captcha: any = "";
  baseurl: any = "";
  captchapic: any = "";
  encrpt: string;
  plainText: string;
  public loading = false;
  dptid: any;
  dptData: any = {};
  constructor(private service: MboardserviceService, private router: Router, private route: ActivatedRoute, private SpinnerService: NgxSpinnerService) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha";
  }

  ngOnInit() {
    this.GetData();
  }
  GetData() {
    this.SpinnerService.show();
    this.route.paramMap.subscribe(params => {
      this.dptid = params.get('dpid');
      this.service.Departmentinfo(this.dptid).subscribe(k => {
        this.dptData = k['result'];
        console.log(this.dptData.departmentId)
        localStorage.setItem('Dep', this.dptData.departmentId);
        this.SpinnerService.hide();
      });
    });
  }
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/SuperAdmin/Captcha?=" + Math.random();
  }
  login(loginData) {
    this.loading = true;
    this.service.AdminLogin(loginData.value).subscribe((data: DisplayMsg) => {
      this.plainText = data.result['userId'].toString();
      console.log(this.plainText)
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "at").toString();
      localStorage.setItem('Token', this.encrpt);
      localStorage.setItem("Roll", "1");
      // localStorage.setItem('Dep', this.dptid);
      this.loading = false;
      this.router.navigate(['/dashboard/Default']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: "Invalid!",
          text: err.error.error,
        })
        this.loading = false;
        this.refreshcaptcha();
        loginData.value.Password = "";
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}

