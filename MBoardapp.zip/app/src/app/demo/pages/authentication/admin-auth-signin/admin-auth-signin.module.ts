import { AppPasswordDirective } from './../../../../resources/app-password.directive';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';
import { AdminAuthSigninComponent } from './admin-auth-signin.component';
import { AdminAuthSigninRoutingModule } from './admin-auth-signin-routing.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

@NgModule({
    imports: [
        CommonModule,
        AdminAuthSigninRoutingModule,
        FormsModule,
        NgxSpinnerModule,
        NgxLoadingModule.forRoot({
            animationType: ngxLoadingAnimationTypes.doubleBounce,
            backdropBorderRadius: '4px',
            primaryColour: '#25476a',
            secondaryColour: '#25476a',
            tertiaryColour: '#25476a',
            fullScreenBackdrop: true
        }),
    ],
    declarations: [AdminAuthSigninComponent, AppPasswordDirective]
})
export class AdminAuthSigninModule { }
