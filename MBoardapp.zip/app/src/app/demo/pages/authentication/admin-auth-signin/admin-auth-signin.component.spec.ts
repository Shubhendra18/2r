import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAuthSigninComponent } from './admin-auth-signin.component';

describe('AdminAuthSigninComponent', () => {
  let component: AdminAuthSigninComponent;
  let fixture: ComponentFixture<AdminAuthSigninComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminAuthSigninComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAuthSigninComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
