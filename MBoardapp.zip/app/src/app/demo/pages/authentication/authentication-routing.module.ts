import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignoutComponent } from './signout/signout.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'signin',
        loadChildren: () => import('./superadmin-auth-signin/superadmin-auth-signin.module').then(m =>
          m.SuperAdminAuthSigninModule)
      },
      {
        path: 'u/:dptid',
        loadChildren: () => import('./auth-signin/auth-signin.module').then(m =>
          m.AuthSigninModule)
      },
      {
        path: 'admin/:dpid',
        loadChildren: () => import('./admin-auth-signin/admin-auth-signin.module').then(m =>
          m.AdminAuthSigninModule)
      },
      {
        path: 'signout',
        component: SignoutComponent, pathMatch: 'full'
      },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthenticationRoutingModule { }
