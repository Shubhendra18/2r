import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SuperadminAuthSigninComponent } from './superadmin-auth-signin.component';

const routes: Routes = [
    {
        path: '',
        component: SuperadminAuthSigninComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SuperAdminAuthSigninRoutingModule { }
