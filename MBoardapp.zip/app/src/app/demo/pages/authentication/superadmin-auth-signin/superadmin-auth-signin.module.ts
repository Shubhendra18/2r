import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';
import { SuperadminAuthSigninComponent } from './superadmin-auth-signin.component';
import { SuperAdminAuthSigninRoutingModule } from './superadmin-auth-signin-routing.module';
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
import { AppPasswordDirective } from 'src/app/resources/app-password.directive';
@NgModule({
    imports: [
        CommonModule,
        SuperAdminAuthSigninRoutingModule,
        FormsModule,
        NgxSpinnerModule,
        NgxLoadingModule.forRoot({
            animationType: ngxLoadingAnimationTypes.doubleBounce,
            backdropBorderRadius: '4px',
            primaryColour: '#25476a',
            secondaryColour: '#25476a',
            tertiaryColour: '#25476a',
            fullScreenBackdrop: true
        }),
    ],
    declarations: [SuperadminAuthSigninComponent, AppPasswordDirective]
})
export class SuperAdminAuthSigninModule { }
