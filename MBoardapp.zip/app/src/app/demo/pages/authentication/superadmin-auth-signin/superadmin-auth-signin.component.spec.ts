import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperadminAuthSigninComponent } from './superadmin-auth-signin.component';

describe('SuperadminAuthSigninComponent', () => {
  let component: SuperadminAuthSigninComponent;
  let fixture: ComponentFixture<SuperadminAuthSigninComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperadminAuthSigninComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperadminAuthSigninComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
