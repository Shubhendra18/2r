import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/theme/shared/shared.module';
import { AddDepartmentRoutingModule } from './adddepartment-routing.module';
import { AdddepartmentComponent } from './adddepartment.component';
import { NgDatepickerModule } from 'ng2-datepicker';

@NgModule({
    imports: [
        CommonModule,
        AddDepartmentRoutingModule,
        SharedModule,
        NgDatepickerModule
    ],
    declarations: [AdddepartmentComponent]
})
export class AddDepartmentModule { }
