import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { DepartmentListRoutingModule } from './departmentlist-routing.module';
import { DepartmentlistComponent } from './departmentlist.component';

@NgModule({
    imports: [
        CommonModule,
        DepartmentListRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [DepartmentlistComponent]
})
export class DepartmentListModule { }
