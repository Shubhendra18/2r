import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperdefaultComponent } from './superdefault.component';

describe('SuperdefaultComponent', () => {
  let component: SuperdefaultComponent;
  let fixture: ComponentFixture<SuperdefaultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperdefaultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperdefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
