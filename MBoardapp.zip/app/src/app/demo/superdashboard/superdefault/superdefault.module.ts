import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { SuperDefaultRoutingModule } from './superdefault-routing.module';
import { SuperdefaultComponent } from './superdefault.component';

@NgModule({
    imports: [
        CommonModule,
        SuperDefaultRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [SuperdefaultComponent]
})
export class SuperDefaultModule { }
