import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import * as CryptoJS from 'crypto-js';
import { DatepickerOptions } from 'ng2-datepicker';
import * as enLocale from 'date-fns/locale/en';
import { MboardserviceService } from 'src/app/mboardservice.service';


@Component({
  selector: 'app-broadcast',
  templateUrl: './broadcast.component.html',
  styleUrls: ['./broadcast.component.scss']
})
export class BroadcastComponent implements OnInit {
  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  public users: any = [];

  decryptnew = localStorage.getItem("Token").toString();
  Sid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);

  dropdownList: any = [];
  selectedItems = [];
  dropdownSettings = {};
  files: File[] = [];
  rId: any[] = [];
  fileToUpload: File = null;
  selectedItemsRoot: any;
  thumbdata = "";
  sdate: Date;

  constructor(private service: MboardserviceService, private toastr: ToastrService) {
    this.sdate = new Date();
  }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;

    });

    this.dropdownSettings = {
      singleSelection: false,
      data: 'dropdownList',
      idField: 'userId',
      textField: 'officeName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }
  options: DatepickerOptions = {
    minYear: 2010,
    maxYear: 2020,
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 1, // 0 - Sunday, 1 - Monday
    locale: enLocale,
    minDate: new Date(Date.now()),
    placeholder: 'Choose a date'
  };

  config = {
    placeholder: 'Type Your Message Here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times'],
    disableDragAndDrop: true,
    tabDisable: false
  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      var data: any = [];
      data = k;
      this.dropdownList = data.filter(o => o['userId'] != this.Sid);
    });
  }

  sendBroadcast(broadcast) {
    this.service.BroadcastPost(this.Sid, broadcast.value.Rid, broadcast.value.Subject, this.fileToUpload, broadcast.value.Message, broadcast.value.sdate).subscribe((data: any) => {
      if (data == "success") {
        this.toastr.success('', 'Broadcast Message Sent');
        this.dropdownList = [];
        this.thumbdata = "";

      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });

  }
  handleFileInput(file: FileList) {
    this.service.PicHandle(file.item(0)).subscribe(
      data => {
        this.fileToUpload = file.item(0);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
          this.thumbdata = "";
        };
      }
    );
  }
  onItemSelect(item: any) {
    this.rId.push(item)
  }
  onSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.rId.push(element)
    }
  }
  onItemDeSelect(item: any) {
    this.rId.splice(item);
  }
  reset() {
    this.files.length = 0;
    this.rId.length = 0;
    this.dropdownList = [];
    this.thumbdata = "";

  }


}
