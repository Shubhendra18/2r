import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { BroadcastComponent } from './broadcast.component';
import { BroadcastRoutingModule } from './broadcast-routing.module';
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxSummernoteModule } from 'ngx-summernote';

@NgModule({
    imports: [
        CommonModule,
        BroadcastRoutingModule,
        SharedModule,
        NgbDropdownModule,
        NgDatepickerModule,
        NgMultiSelectDropDownModule,
        NgxSummernoteModule
    ],
    declarations: [BroadcastComponent]
})
export class BroadcastModule { }
