import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendreceivestatsComponent } from './sendreceivestats.component';

describe('SendreceivestatsComponent', () => {
  let component: SendreceivestatsComponent;
  let fixture: ComponentFixture<SendreceivestatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendreceivestatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendreceivestatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
