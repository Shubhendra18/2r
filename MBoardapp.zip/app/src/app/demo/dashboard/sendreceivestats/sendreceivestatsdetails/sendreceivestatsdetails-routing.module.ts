import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SendreceivestatsdetailsComponent } from './sendreceivestatsdetails.component';

const routes: Routes = [
    {
        path: '',
        component: SendreceivestatsdetailsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SendReceiveStatsDetailsRoutingModule { }
