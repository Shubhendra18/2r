import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendreceivestatsdetailsComponent } from './sendreceivestatsdetails.component';

describe('SendreceivestatsdetailsComponent', () => {
  let component: SendreceivestatsdetailsComponent;
  let fixture: ComponentFixture<SendreceivestatsdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendreceivestatsdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendreceivestatsdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
