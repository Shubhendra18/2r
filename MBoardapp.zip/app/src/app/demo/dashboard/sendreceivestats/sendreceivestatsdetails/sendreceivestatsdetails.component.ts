import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-sendreceivestatsdetails',
  templateUrl: './sendreceivestatsdetails.component.html',
  styleUrls: ['./sendreceivestatsdetails.component.scss']
})
export class SendreceivestatsdetailsComponent implements OnInit {
  flag: string = "";
  userId: any = "";
  userName: string = "";
  senderorReceiver: any = "";
  type: string = "";

  SendMsgListData: any = [];
  RecMsgListData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  sendrecDes: any = [];

  constructor(private service: MboardserviceService, private route: ActivatedRoute, private modalService: NgbModal) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.flag = params.get('flag');
      this.userId = params.get('uid');

      if (this.flag == 'S') {
        var message = { 'userId': this.userId, 'flag': 'S' };
        this.service.GetSendMsgList(message).subscribe(k => {
          this.SendMsgListData = k;
          this.type = "Sent";
          this.senderorReceiver = "Sent To";
          this.dtTrigger.next();

        });

      }
      else if (this.flag == 'R') {
        var message = { 'userId': this.userId, 'flag': 'R' };
        this.service.GetSendMsgList(message).subscribe(k => {
          this.SendMsgListData = k;
          this.type = "Received";
          this.senderorReceiver = "Received From";
          this.dtTrigger.next();

        });
      }

      this.service.UserLastLogin(this.userId).subscribe(k => {
        this.userName = k['officeName'];
      });
      this.dtOptions = {
        pageLength: 10, pagingType: 'full_numbers'
      };
    });

  }
  sendrecDeatils(mailId, content) {
    this.modalService.open(content, { centered: true });
    this.sendrecDes = (this.SendMsgListData.filter(k => k.mailId == mailId));
  }
  Download(attachment) {
    this.service.DownloadAttachments(attachment).subscribe(k => {
    });
  }
}