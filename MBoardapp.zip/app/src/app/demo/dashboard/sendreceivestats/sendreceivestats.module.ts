import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { SendreceivestatsComponent } from './sendreceivestats.component';
import { DataTablesModule } from 'angular-datatables';
import { SendReceiveStatsRoutingModule } from './sendreceivestats-routing.module';
import { SendReceiveStatsDetailsModule } from './sendreceivestatsdetails/sendreceivestatsdetails.module';

@NgModule({
    imports: [
        CommonModule,
        SendReceiveStatsRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule,
        SendReceiveStatsDetailsModule
    ],
    declarations: [SendreceivestatsComponent]
})
export class SendReceiveStatsModule { }
