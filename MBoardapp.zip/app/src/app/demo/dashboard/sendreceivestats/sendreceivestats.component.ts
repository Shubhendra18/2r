import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';

@Component({
  selector: 'app-sendreceivestats',
  templateUrl: './sendreceivestats.component.html',
  styleUrls: ['./sendreceivestats.component.scss']
})
export class SendreceivestatsComponent implements OnInit {
  sendrecstats: any = [];
  SendMsgListData: any = [];
  RecMsgListData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  totaluser: any;
  totalsenmsg: any;
  totalrecmsg: any;

  constructor(private service: MboardserviceService, private route: Router, private routet: ActivatedRoute) {

  }

  ngOnInit() {
    this.service.GetsendreceiveStats().subscribe(k => {
      this.sendrecstats = k;
      this.totaluser = this.sendrecstats.length;
      this.totalsenmsg = this.sendrecstats.map(t => t.cn1).reduce((a, value) => a + value, 0);
      this.totalrecmsg = this.sendrecstats.map(t => t.cn2).reduce((a, value) => a + value, 0);

      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  SendMsgList(userId) {
    this.route.navigate(['/dashboard/Send-Receive-Msg/', userId, 'S']);
  }
  ReceiveMsgList(userId) {
    this.route.navigate(['/dashboard/Send-Receive-Msg/', userId, 'R']);
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

}
