import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { MessageUserRoutingModule } from './messagereport-routing.module';
import { MessagereportComponent } from './messagereport.component';
import { DataTablesModule } from 'angular-datatables';
import { NgDatepickerModule } from 'ng2-datepicker';
import { NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    imports: [
        CommonModule,
        MessageUserRoutingModule,
        SharedModule,
        DataTablesModule,
        NgDatepickerModule,
        NgbTabsetModule
    ],
    declarations: [MessagereportComponent]
})
export class MessageReportModule { }
