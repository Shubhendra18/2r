import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare var $;

@Component({
  selector: 'app-manageuser',
  templateUrl: './manageuser.component.html',
  styleUrls: ['./manageuser.component.scss']
})
export class ManageuserComponent implements OnInit, OnDestroy {
  manageUserList: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  updateUserName: string = "";
  updateUserMobile: string = "";
  updateUserid: string = "";

  message = 'false';
  isActive: boolean = true;
  checkbox: boolean;
  public show: boolean = false;
  public buttonName: any = 'Show';
  public loading = false;
  values = '';
  mobilealreadytaken: boolean = false;
  alreadytaken: boolean = false;
  current: any = [];

  constructor(private service: MboardserviceService, private toaster: ToastrService, private modalService: NgbModal) { }

  ngOnInit() {
    this.service.GetGroupUserForManage(0).subscribe(k => {
      this.current = k;
      this.manageUserList = this.current.filter(function (x) { return x['groupID'] !== 4; });
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true

    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByFn(index: number, item) {
    return index;
  }
  tosendUpdate(k, content) {
    this.modalService.open(content, { centered: true });

    this.updateUserName = k.officeName;
    this.updateUserMobile = k.mobileNo;
    this.updateUserid = k.userId;
  }
  ManageUserMaster(ManageUserData) {
    this.service.updateUserMaster(ManageUserData.value).subscribe(k => {
      if (k == 'Success') {
        this.toaster.success('', 'User Details Updated Successfully');
        $("#userEdit").modal('hide');
        this.service.GetGroupUserForManage(0).subscribe(k => {
          this.manageUserList = k;
        });
      }
      else {
        this.toaster.error('Failed to Updated', 'Error');
      }
    });

  }

  actdeact(userId, recflag) {
    this.loading = true;

    var activeDeactive = { 'recflag': recflag, 'userId': userId };
    this.service.ActiveDeactiveUser(activeDeactive).subscribe(k => {
      this.service.GetGroupUserForManage(0).subscribe(k => {
        this.manageUserList = k;
        this.loading = false;

      });
    });
  }
  onChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '0' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.alreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytaken = true;
      };
    });
  }
  onMobileChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '1' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.mobilealreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.mobilealreadytaken = true;
      };
    });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  Close() {
    this.mobilealreadytaken = false;
    this.alreadytaken = false;
  }
  openVerticallyCentered(content) {
    this.modalService.open(content, { centered: true });
  }

}
