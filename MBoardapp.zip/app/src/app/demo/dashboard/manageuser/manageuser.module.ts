import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ManageUserRoutingModule } from './manageuser-routing.module';
import { ManageuserComponent } from './manageuser.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        ManageUserRoutingModule,
        SharedModule,
        NgbDropdownModule,
        NgbModalModule,
        DataTablesModule
    ],
    declarations: [ManageuserComponent]
})
export class ManageUserModule { }
