import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BroadcaststatsComponent } from './broadcaststats.component';

const routes: Routes = [
    {
        path: '',
        component: BroadcaststatsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class BroadcastStatsRoutingModule { }
