import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BroadcaststatsComponent } from './broadcaststats.component';

describe('BroadcaststatsComponent', () => {
  let component: BroadcaststatsComponent;
  let fixture: ComponentFixture<BroadcaststatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BroadcaststatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BroadcaststatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
