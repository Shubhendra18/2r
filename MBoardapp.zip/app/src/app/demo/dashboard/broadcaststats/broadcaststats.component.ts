import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-broadcaststats',
  templateUrl: './broadcaststats.component.html',
  styleUrls: ['./broadcaststats.component.scss']
})
export class BroadcaststatsComponent implements OnInit, OnDestroy {
  bradocastrpt: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  bradoDes: any = [];
  baseurl: any = "";

  constructor(private service: MboardserviceService, private modalService: NgbModal) {
    this.baseurl = this.service.getbaseurl();

  }
  ngOnInit() {
    this.service.GetBroadcastReport().subscribe(k => {
      this.bradocastrpt = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true
    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  BroadcastDetails(rowId,content) {
    this.modalService.open(content, { centered: true });
    this.bradoDes = (this.bradocastrpt.filter(k => k.rowId == rowId));
  }
  openVerticallyCentered(content) {
    this.modalService.open(content, { centered: true });
  }

}
