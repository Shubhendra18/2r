import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { BroadcastStatsRoutingModule } from './broadcaststats-routing.module';
import { BroadcaststatsComponent } from './broadcaststats.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        BroadcastStatsRoutingModule,
        SharedModule,
        NgbModalModule,
        DataTablesModule
    ],
    declarations: [BroadcaststatsComponent]
})
export class BroadcastStatsModule { }
