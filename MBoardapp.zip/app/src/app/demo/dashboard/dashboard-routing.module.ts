import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'Default',
        loadChildren: './default/default.module#DefaultModule'
      },
      {
        path: 'Manage-Group',
        loadChildren: './managegroup/managegroup.module#ManageGroupModule'
      },
      {
        path: 'Create-User',
        loadChildren: './createuser/createuser.module#CreateUserModule'
      },
      {
        path: 'Manage-User',
        loadChildren: './manageuser/manageuser.module#ManageUserModule'
      },
      {
        path: 'Broadcast',
        loadChildren: './broadcast/broadcast.module#BroadcastModule'
      },
      {
        path: 'Last-Login',
        loadChildren: './lastloginreport/lastloginreport.module#LastLoginReportModule'
      },
      {
        path: 'Message-Report',
        loadChildren: './messagereport/messagereport.module#MessageReportModule'
      },
      {
        path: 'Active-Inactive-User',
        loadChildren: './activeinactiveuser/activeinactive.module#ActiveInactiveModule'
      },
      {
        path: 'Send-Receive-Msg',
        loadChildren: './sendreceivestats/sendreceivestats.module#SendReceiveStatsModule'
      },
      {
        path: 'Broadcast-Statistics',
        loadChildren: './broadcaststats/broadcaststats.module#BroadcastStatsModule'
      },
      
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
