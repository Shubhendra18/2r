import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { LastLoginReportRoutingModule } from './lastloginreport-routing.module';
import { LastloginreportComponent } from './lastloginreport.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        LastLoginReportRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule
    ],
    declarations: [LastloginreportComponent]
})
export class LastLoginReportModule { }
