import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';

@Component({
  selector: 'app-lastloginreport',
  templateUrl: './lastloginreport.component.html',
  styleUrls: ['./lastloginreport.component.scss']
})
export class LastloginreportComponent implements OnInit {
  loginrptData: any = [];
  dtOptions: DataTables.Settings = {

  };
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService) { }

  ngOnInit() {
    this.service.GetLastLogin().subscribe(k => {
      this.loginrptData = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
