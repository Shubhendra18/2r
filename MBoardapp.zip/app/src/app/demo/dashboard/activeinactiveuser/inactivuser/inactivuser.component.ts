import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';

@Component({
  selector: 'app-inactivuser',
  templateUrl: './inactivuser.component.html',
  styleUrls: ['./inactivuser.component.scss']
})
export class InactivuserComponent implements OnInit {

  usedUserData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService) { }
  ngOnInit() {
    this.service.GetNotUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
}
