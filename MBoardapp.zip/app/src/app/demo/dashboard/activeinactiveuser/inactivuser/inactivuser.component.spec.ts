import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InactivuserComponent } from './inactivuser.component';

describe('InactivuserComponent', () => {
  let component: InactivuserComponent;
  let fixture: ComponentFixture<InactivuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InactivuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InactivuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
