import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ActiveInactiveRoutingModule } from './activeinactive-routing.module';
import { ActiveinactiveuserComponent } from './activeinactiveuser.component';
import { ActivuserComponent } from './activuser/activuser.component';
import { InactivuserComponent } from './inactivuser/inactivuser.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
        CommonModule,
        ActiveInactiveRoutingModule,
        SharedModule,
        NgbDropdownModule,
        DataTablesModule
    ],
    declarations: [ActiveinactiveuserComponent, ActivuserComponent, InactivuserComponent]
})
export class ActiveInactiveModule { }
