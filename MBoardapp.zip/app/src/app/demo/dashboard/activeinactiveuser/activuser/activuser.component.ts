
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MboardserviceService } from 'src/app/mboardservice.service';
@Component({
  selector: 'app-activuser',
  templateUrl: './activuser.component.html',
  styleUrls: ['./activuser.component.scss']
})
export class ActivuserComponent implements OnInit {
  usedUserData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MboardserviceService) { }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
}
