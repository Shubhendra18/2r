import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivuserComponent } from './activuser.component';

describe('ActivuserComponent', () => {
  let component: ActivuserComponent;
  let fixture: ComponentFixture<ActivuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
