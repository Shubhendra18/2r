import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveinactiveuserComponent } from './activeinactiveuser.component';

describe('ActiveinactiveuserComponent', () => {
  let component: ActiveinactiveuserComponent;
  let fixture: ComponentFixture<ActiveinactiveuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveinactiveuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveinactiveuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
