import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MboardserviceService {
  //private baseUrl = "http://demo.otpl.in/mbapi"
  //public buttonClick = new Subject();
  //private baseUrl = "http://localhost:4876";
  private baseUrl = "http://localhost:61658";


  constructor(private http: HttpClient) { }

  getbaseurl() {
    return this.baseUrl;
  }
  getDataTable() {
    return {
      pageLength: 25, dom: 'frtip', paging: true,
      language: {
        "info": "_START_ - _END_ of _TOTAL_ ",
        "paginate": {
          previous: "<",
          next: ">"
        }
      }
    };
  }
  //****************************************************Super Admin Api Call*********************************************************************/
  AdminstratorLogin(loginData) {
    return this.http.post(this.baseUrl + "/SuperAdmin/Login", loginData);
  }
  Departmentinfo(dptid) {
    return this.http.get(this.baseUrl + "/SuperAdmin/LoginInfo/" + dptid);
  }
  DBConfigData(dptid) {
    return this.http.get(this.baseUrl + "/api/DBConfig/" + dptid);
  }
  AddDepartment(dptName: string, title: string, address: string, email: string, mobileNo: string, fileToUpload: File, Sedate, maxuser: string) {
    const formData: FormData = new FormData();
    formData.append('DepartmentName', dptName);
    formData.append('Title', title);
    formData.append('Address', address);
    formData.append('Email', email);
    formData.append('Mobile', mobileNo);
    formData.append('Logo', fileToUpload);
    formData.append('Sedate', Sedate);
    formData.append('Maxuser', maxuser);

    return this.http.post(this.baseUrl + "/SuperAdmin/Department", formData);
  }
  DepartmentList() {
    return this.http.get(this.baseUrl + "/SuperAdmin/DepartmentList");
  }
  AdminList() {
    return this.http.get(this.baseUrl + "/SuperAdmin/AdminList");
  }
  AddDBConfig(dbConfig) {
    return this.http.post(this.baseUrl + "/SuperAdmin/DBConfig", dbConfig);
  }
  UpdateDptdata(model) {
    return this.http.post(this.baseUrl + "/SuperAdmin/DepartmentInfo", model);
  }
  UpdateSubcriptiondata(model) {
    return this.http.post(this.baseUrl + "/SuperAdmin/SubcriptionInfo", model);
  }
  //****************************************************Admin Api Call*********************************************************************/

  AdminLogin(loginData) {
    return this.http.post(this.baseUrl + "/api/AdminLogin", loginData);
  }
  UserLastLogin(userId) {
    return this.http.get(this.baseUrl + "/api/LastLogin/" + userId);
  }
  UpdateProfile(mobileNo: string, fileToUpload: File, userId) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload);
    formData.append('mobileNo', mobileNo);
    formData.append('userId', userId);
    return this.http.post(this.baseUrl + "/api/UpdateProfile", formData);
  }


  FileHandle(fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload, fileToUpload.name);
    return this.http.post(this.baseUrl + "/File/FileValidation", formData);
  }
  PicHandle(fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload, fileToUpload.name);
    return this.http.post(this.baseUrl + "/File/PicValidation", formData);
  }




  Attachmentsfiles(fileToUpload, Priority, SMS, Subject, Message, Sid, Rid) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    formData.append('Priority', Priority);
    formData.append('SMS', SMS);
    formData.append('Subject', Subject);
    formData.append('Message', Message);
    formData.append('Sid', Sid);
    return this.http.post(this.baseUrl + "/api/ComposeMailWithAttachment", formData);
  }


  GroupMaster() {
    return this.http.get(this.baseUrl + "/api/GroupMaster");
  }
  AddUpdateGroupMaster(groupMasterData) {
    return this.http.post(this.baseUrl + "/api/AddUpdateGroupMaster", groupMasterData);
  }
  DeleteGroupMaster(groupId) {
    console.log(groupId);
    return this.http.get(this.baseUrl + "/api/DeleteGroupMaster/" + groupId);
  }
  composemail(mailBox) {
    return this.http.post(this.baseUrl + "/api/ComposeMail", mailBox);
  }
  MoveToDraft(Priority, SMS, Subject, Message, Sid) {
    var mailBox = { Priority, SMS, Subject, Message, Sid }
    return this.http.post(this.baseUrl + "/api/Drafts", mailBox);
  }
  allMailFromDraft(Rid) {
    return this.http.get(this.baseUrl + "/api/FromDraft/" + Rid);
  }
  GetGroupUserForManage(groupId) {
    return this.http.get(this.baseUrl + "/api/GetGroupUserForManage/" + groupId);
  }
  updateUserMaster(ManageUserData) {
    return this.http.post(this.baseUrl + "/api/updateUserMaster", ManageUserData);
  }
  GetLastLogin() {
    return this.http.get(this.baseUrl + "/api/GetLastLogin");
  }
  chkgroupName(groupName) {
    return this.http.get(this.baseUrl + "/api/CheckGroupName/" + groupName);
  }
  GetsendreceiveStats() {
    return this.http.get(this.baseUrl + "/api/SendReceiveStats");
  }
  GetUsedUser() {
    return this.http.get(this.baseUrl + "/api/UsedUser");
  }
  GetNotUsedUser() {
    return this.http.get(this.baseUrl + "/api/NotUsedUser");
  }
  ActiveDeactiveUser(activeDeactive) {
    return this.http.post(this.baseUrl + "/api/ActiveDeactiveUser", activeDeactive);
  }
  GetallOffieName() {
    return this.http.get(this.baseUrl + "/api/GetAllOffice");
  }
  ReportByOfficeName(userId) {
    return this.http.get(this.baseUrl + "/api/MsgReportByOfficeName/" + userId);
  }
  ReportBysubject(subject) {
    return this.http.get(this.baseUrl + "/api/MsgReportBySuject/" + subject);
  }
  ReportBydate(date) {
    return this.http.post(this.baseUrl + "/api/MsgReportByDate", date);
  }
  // BroadcastPost(broadCast) {
  //   return this.http.post(this.baseUrl + "/api/Broadcast", broadCast);
  // }

  BroadcastPost(Sid, Rid, subject, fileToUpload, Message, sdate) {
    const formData: FormData = new FormData();
    formData.append('BroadcastPic', fileToUpload);
    formData.append('Sid', Sid);
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    formData.append('Subject', subject);
    formData.append('Message', Message);
    formData.append('ClosedDate', sdate);


    return this.http.post(this.baseUrl + "/api/Broadcast", formData);
  }
  BroadcastGet(rid) {
    return this.http.get(this.baseUrl + "/api/BroadcastMessage/" + rid);
  }
  MarkBroadcastSeen(rowid) {
    return this.http.get(this.baseUrl + "/api/MarkBroadcastMessageSeen/" + rowid);
  }
  GetBroadcastReport() {
    return this.http.get(this.baseUrl + "/api/BroadcastReport");
  }
  GetSendMsgList(message) {
    return this.http.post(this.baseUrl + "/api/GetSendMessage", message);
  }
  //****************************************************User Api Call*********************************************************************/
  UserLogin(loginData) {
    return this.http.post(this.baseUrl + "/api/UserLogin", loginData);
  }
  chkNameorMobile(userorMobile) {
    return this.http.post(this.baseUrl + "/api/CheckuserOrMobile", userorMobile);
  }
  AddUser(addUser) {
    return this.http.post(this.baseUrl + "/api/AddUser", addUser);
  }
  GetUserBygroup(groupId) {
    return this.http.get(this.baseUrl + "/api/GetUserBygroup/" + groupId);
  }
  getmail(Rid) {
    return this.http.get(this.baseUrl + "/api/InboxMail/" + Rid);
  }

  // getmail(datat) {
  //   return this.http.post(this.baseUrl + "/api/InboxMail", datat);
  // }


  getmailDetails(mailDes) {
    return this.http.post(this.baseUrl + "/api/MailDetails", mailDes);
  }
  getdraftDetails(mailDes) {
    return this.http.post(this.baseUrl + "/api/DraftDetails", mailDes);
  }
  getattachments(mailDes) {
    return this.http.post(this.baseUrl + "/api/Attachments", mailDes);
  }
  getSentattachments(mailDes) {
    return this.http.post(this.baseUrl + "/api/SentAttachments", mailDes);
  }
  DownloadAttachments(fileName) {
    var downloadFile = { 'fileName': fileName }
    console.log(downloadFile)
    return this.http.post(this.baseUrl + "/api/GetAttachmentFile", downloadFile, { responseType: 'blob' });
  }

  moveToTrash(SelectedIDs) {
    return this.http.get(this.baseUrl + "/api/MoveToTrash/" + SelectedIDs);
  }
  allMailsmoveToTrash(moveToTrash) {
    return this.http.post(this.baseUrl + "/api/AllMailMoveToTrash", moveToTrash);
  }
  allMailFromTrash(Rid) {
    return this.http.get(this.baseUrl + "/api/FromTrash/" + Rid);
  }
  deleteFromTrash(MailId) {
    return this.http.delete(this.baseUrl + "/api/DeleteFromTrash/" + MailId);
  }


  moveToArchive(SelectedIDs) {
    return this.http.get(this.baseUrl + "/api/MoveToArchive/" + SelectedIDs);
  }
  allMailsmoveToArchive(moveToArchive) {
    return this.http.post(this.baseUrl + "/api/AllMailMoveToArchive", moveToArchive);
  }
  allMailFromArchive(Rid) {
    return this.http.get(this.baseUrl + "/api/FromArchive/" + Rid);
  }
  backToInbox(moveToInbox) {
    return this.http.post(this.baseUrl + "/api/MovebackToInbox", moveToInbox);
  }
  moveToImportant(mailId) {
    return this.http.get(this.baseUrl + "/api/MoveToImportant/" + mailId);
  }
  allMailFromImportant(Rid) {
    return this.http.get(this.baseUrl + "/api/AllMailFromImportant/" + Rid);
  }
  forgetPassword(mobileNo) {
    return this.http.get(this.baseUrl + "/api/ForgetPassword/" + mobileNo);
  }
  otpVerification(mobileNo, OTP) {
    var verifyOTP = { 'mobileNo': mobileNo, 'OTP': OTP }
    return this.http.post(this.baseUrl + "/api/VerifyOTP", verifyOTP);
  }
  changePassword(userId, Password) {
    var changePassword = { 'userId': userId, 'Password': Password }
    return this.http.post(this.baseUrl + "/api/ChangePassword", changePassword);
  }
  allMailFromSent(Sid) {
    return this.http.get(this.baseUrl + "/api/SentMails/" + Sid);
  }
  GetSentMailDetails(sendMailDes) {
    return this.http.post(this.baseUrl + "/api/SentMailDes", sendMailDes);
  }
  CheckOldPass(userId, OldPass) {
    var checkOldPass = { 'userId': userId, 'OldPass': OldPass }
    return this.http.post(this.baseUrl + "/api/CheckOldPass", checkOldPass);
  }
  // SendMailReply(reply) {
  //   return this.http.post(this.baseUrl + "/api/MailReply", reply);
  // }
  SendMailReply(fileToUpload, Sid, Rid, Message, MessageId, Priority, Subject) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    formData.append('Sid', Sid);
    formData.append('Rid', Rid);
    formData.append('Message', Message);
    formData.append('MessageId', MessageId);
    formData.append('Priority', Priority);
    formData.append('Subject', Subject);

    return this.http.post(this.baseUrl + "/api/MailReply", formData);
  }

  ShowMailReply(sendMailDes) {
    return this.http.post(this.baseUrl + "/api/ShowMailReply", sendMailDes);
  }

  getmailhead(mailDes) {
    return this.http.post(this.baseUrl + "/api/GetMailHead", mailDes);
  }
  updatedraft(msgId) {
    console.log(msgId)
    return this.http.get(this.baseUrl + "/api/UpdateDraft/" + msgId);
  }

  //**************forwrd */
  getforword(forword) {
    return this.http.post(this.baseUrl + "/api/GetForword", forword);
  }
  ForwarMailWithfiles(fileToUpload, Priority, SMS, Subject, Message, Sid, Rid, OldFiles) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    for (let i = 0; i < OldFiles.length; i++) {
      formData.append("OldFiles", OldFiles[i]);
    }
    formData.append('Priority', Priority);
    formData.append('SMS', SMS);
    formData.append('Subject', Subject);
    formData.append('Message', Message);
    formData.append('Sid', Sid);
    return this.http.post(this.baseUrl + "/api/Forwarmail", formData);
  }
}
