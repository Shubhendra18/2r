import { Injectable } from '@angular/core';
import { SidebarupdateService } from 'src/app/demo/pages/form-elements/sidebarupdate.service';
import * as CryptoJS from 'crypto-js';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [
  {
    id: 'AdminPanel',
    title: 'Admin Panel',
    type: 'group',
    icon: 'lni-cog',
    children: [
      {
        id: 'Dashboard',
        title: 'Dashboard',
        type: 'collapse',
        icon: 'lni-cog',
        children: [
          {
            id: 'Default',
            title: 'Default',
            type: 'item',
            url: '/dashboard/Default'
          },
          {
            id: 'ManageGroup',
            title: 'Create & Manage Group',
            type: 'item',
            url: '/dashboard/Manage-Group'
          },
          {
            id: 'CreateUser',
            title: 'Create user',
            type: 'item',
            url: '/dashboard/Create-User'
          },
          {
            id: 'ManageUser',
            title: 'Manage User',
            type: 'item',
            url: '/dashboard/Manage-User'
          },
          {
            id: 'Broadcast',
            title: 'Broadcast',
            type: 'item',
            url: '/dashboard/Broadcast'
          },
          {
            id: 'LastLogin',
            title: 'User Last Login Report',
            type: 'item',
            url: '/dashboard/Last-Login'
          },
          {
            id: 'MessageReport',
            title: 'Message Report',
            type: 'item',
            url: '/dashboard/Message-Report'
          },
          {
            id: 'ActiveInactiveUser',
            title: 'Active & Inactive Users',
            type: 'item',
            url: '/dashboard/Active-Inactive-User'
          },
          {
            id: 'SendReceiveMsg',
            title: 'Sent/Received Messages',
            type: 'item',
            url: '/dashboard/Send-Receive-Msg'
          },
          {
            id: 'BroadcastStatistics',
            title: 'Broadcast Statistics',
            type: 'item',
            url: '/dashboard/Broadcast-Statistics'
          }
        ]
      }
    ]
  },
  {
    id: 'forms',
    title: 'Navigation',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'Inbox',
        title: 'Inbox',
        type: 'item',
        url: '/u/Inbox',
        icon: 'lni-popup',
        classes: 'nav-item',
        badge: {
          title: '10',
          type: 'badge-info'
        }
      },
      {
        id: 'Compose',
        title: 'Compose',
        type: 'item',
        url: '/u/Compose',
        icon: 'lni-pencil',
        classes: 'nav-item'
      },
      {
        id: 'Sent',
        title: 'Sent',
        type: 'item',
        url: '/u/Sent',
        icon: 'lni-pointer',
        classes: 'nav-item',
        badge: {
          title: '15',
          type: 'badge-warning'
        }
      },
      {
        id: 'Important',
        title: 'Important',
        type: 'item',
        url: '/u/Important',
        icon: 'lni-star',
        classes: 'nav-item',
        badge: {
          title: '9',
          type: 'badge-success'
        }
      }
      ,
      {
        id: 'Archive',
        title: 'Archive',
        type: 'item',
        url: '/u/Archive',
        icon: 'lni-archive',
        classes: 'nav-item',
        badge: {
          title: '11',
          type: 'badge-dark'
        }
      },
      {
        id: 'Draft',
        title: 'Draft',
        type: 'item',
        url: '/u/Draft',
        icon: 'lni-write',
        classes: 'nav-item',
        badge: {
          title: '8',
          type: 'badge-primary'
        }
      },
      {
        id: 'Trash',
        title: 'Trash',
        type: 'item',
        url: '/u/Trash',
        icon: 'lni-trash',
        classes: 'nav-item',
        badge: {
          title: '16',
          type: 'badge-danger'
        }
      },
      {
        id: 'Sign out',
        title: 'Sign out',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'lni-power-switch',
        classes: 'nav-item'
      }
    ]
  },

];

@Injectable()
export class NavigationItem {
  totalinbox: number = 0;
  totasend: number = 0;
  totaimportant: number = 0;
  totadarft: number = 0;
  totalarchive: number = 0;
  totaltrash: number = 0;


  listinbox: any = [];
  listsend: any = [];
  listimportant: any = [];
  listdarft: any = [];
  listarchive: any = [];
  listtrash: any = [];
  //decryptnew = localStorage.getItem("Token").toString();
  //Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);

  constructor(private sidebarse: SidebarupdateService) {
    // this.sidebarse.getmail(this.Rid).subscribe(k => {
    //   this.listinbox = k;
    //   this.totalinbox = this.listinbox.length;
    // });
  }
  get() {
    return [
      {
        id: 'AdminPanel',
        title: 'Admin Panel',
        type: 'group',
        icon: 'lni-cog',
        children: [
          {
            id: 'Dashboard',
            title: 'Dashboard',
            type: 'collapse',
            icon: 'lni-cog',
            url: '/dashboard/Default',
            children: [
              {
                id: 'Default',
                title: 'Default',
                type: 'item',
                url: '/dashboard/Default'
              },
              {
                id: 'ManageGroup',
                title: 'Create & Manage Group',
                type: 'item',
                url: '/dashboard/Manage-Group'
              },
              {
                id: 'CreateUser',
                title: 'Create user',
                type: 'item',
                url: '/dashboard/Create-User'
              },
              {
                id: 'ManageUser',
                title: 'Manage User',
                type: 'item',
                url: '/dashboard/Manage-User'
              },
              {
                id: 'Broadcast',
                title: 'Broadcast',
                type: 'item',
                url: '/dashboard/Broadcast'
              },
              {
                id: 'LastLogin',
                title: 'User Last Login Report',
                type: 'item',
                url: '/dashboard/Last-Login'
              },
              {
                id: 'MessageReport',
                title: 'Message Report',
                type: 'item',
                url: '/dashboard/Message-Report'
              },
              {
                id: 'ActiveInactiveUser',
                title: 'Active & Inactive Users',
                type: 'item',
                url: '/dashboard/Active-Inactive-User'
              },
              {
                id: 'SendReceiveMsg',
                title: 'Sent/Received Messages',
                type: 'item',
                url: '/dashboard/Send-Receive-Msg'
              },
              {
                id: 'BroadcastStatistics',
                title: 'Broadcast Statistics',
                type: 'item',
                url: '/dashboard/Broadcast-Statistics'
              }
            ]
          }
        ]
      },
      {
        id: 'forms',
        title: 'Navigation',
        type: 'group',
        icon: 'icon-group',
        children: [
          {
            id: 'Inbox',
            title: 'Inbox',
            type: 'item',
            url: '/u/Inbox',
            icon: 'lni-popup',
            classes: 'nav-item',
            badge: {
              title: this.totalinbox,
              type: 'badge-info'
            }
          },
          {
            id: 'Compose',
            title: 'Compose',
            type: 'item',
            url: '/u/Compose',
            icon: 'lni-pencil',
            classes: 'nav-item'
          },
          {
            id: 'Sent',
            title: 'Sent',
            type: 'item',
            url: '/u/Sent',
            icon: 'lni-pointer',
            classes: 'nav-item',
            badge: {
              title: '15',
              type: 'badge-warning'
            }
          },
          {
            id: 'Important',
            title: 'Important',
            type: 'item',
            url: '/u/Important',
            icon: 'lni-star',
            classes: 'nav-item',
            badge: {
              title: '9',
              type: 'badge-success'
            }
          }
          ,
          {
            id: 'Archive',
            title: 'Archive',
            type: 'item',
            url: '/u/Archive',
            icon: 'lni-archive',
            classes: 'nav-item',
            badge: {
              title: '11',
              type: 'badge-dark'
            }
          },
          {
            id: 'Draft',
            title: 'Draft',
            type: 'item',
            url: '/u/Draft',
            icon: 'lni-write',
            classes: 'nav-item',
            badge: {
              title: '8',
              type: 'badge-primary'
            }
          },
          {
            id: 'Trash',
            title: 'Trash',
            type: 'item',
            url: '/u/Trash',
            icon: 'lni-trash',
            classes: 'nav-item',
            badge: {
              title: '16',
              type: 'badge-danger'
            }
          },
          {
            title: 'Sign out',
            type: 'item',
            url: '/auth/signout',
            icon: 'lni-power-switch',
            classes: 'nav-item',
            exactMatch: true,
            breadcrumbs: false
          },
        ]
      },

    ];
  }
}
