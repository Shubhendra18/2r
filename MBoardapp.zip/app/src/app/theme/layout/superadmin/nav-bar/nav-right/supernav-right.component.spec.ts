import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavRightComponent } from './supernav-right.component';

describe('SuperNavRightComponent', () => {
  let component: SuperNavRightComponent;
  let fixture: ComponentFixture<SuperNavRightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SuperNavRightComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
