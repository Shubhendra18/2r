import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavBarComponent } from './supernav-bar.component';

describe('SuperNavBarComponent', () => {
  let component: SuperNavBarComponent;
  let fixture: ComponentFixture<SuperNavBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperNavBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
