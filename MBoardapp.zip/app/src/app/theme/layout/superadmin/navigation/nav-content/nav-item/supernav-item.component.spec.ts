import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavItemComponent } from './supernav-item.component';

describe('SuperNavItemComponent', () => {
  let component: SuperNavItemComponent;
  let fixture: ComponentFixture<SuperNavItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SuperNavItemComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
