import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavGroupComponent } from './supernav-group.component';

describe('SuperNavGroupComponent', () => {
  let component: SuperNavGroupComponent;
  let fixture: ComponentFixture<SuperNavGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SuperNavGroupComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
