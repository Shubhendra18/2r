import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavigationComponent } from './supernavigation.component';

describe('SuperNavigationComponent', () => {
  let component: SuperNavigationComponent;
  let fixture: ComponentFixture<SuperNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SuperNavigationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
