import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavCollapseComponent } from './supernav-collapse.component';

describe('SuperNavCollapseComponent', () => {
  let component: SuperNavCollapseComponent;
  let fixture: ComponentFixture<SuperNavCollapseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SuperNavCollapseComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavCollapseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
