import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperbreadcrumbComponent } from './superbreadcrumb.component';

describe('SuperbreadcrumbComponent', () => {
  let component: SuperbreadcrumbComponent;
  let fixture: ComponentFixture<SuperbreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperbreadcrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperbreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
