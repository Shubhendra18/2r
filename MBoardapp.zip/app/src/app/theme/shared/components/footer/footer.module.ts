import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { AnimationService, AnimatorModule } from 'css-animator';
import { FooterComponent } from './footer.component';

@NgModule({
    imports: [
        CommonModule,
        NgbDropdownModule,
        AnimatorModule
    ],
    declarations: [FooterComponent],
    exports: [FooterComponent],
    providers: [AnimationService]
})
export class FooterModule { }
