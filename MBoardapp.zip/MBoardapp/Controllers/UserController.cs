﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using MBoardapp.Filters;
using MBoardapp.Models;
using MBoardapp.Repository;

namespace MBoardapp.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]

    [RoutePrefix("User")]
    public class UserController : ApiController
    {
        UserContext da = new UserContext();
        //AdminContext adminContext = new AdminContext();
        DisplayMessage displayMessage = new DisplayMessage();
        Common objCom = new Common();
       
        [Route("InboxMail/{Rid}")]
        public IHttpActionResult GetMail(Int64 Rid)
        {
            List<UserInbox> data = da.GetUsermail(Rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        //[Route("InboxMail")]
        //public IHttpActionResult PostMail(PagedModel model)
        //{
        //    PagedResponse<List<UserInbox>> pagedData = new PagedResponse<List<UserInbox>>();
        //    pagedData.Total = da.GetUsermail(model.rid).Count();
        //    double pageCount = (double)(pagedData.Total / model.itemsPerPage);
        //    pagedData.NumberOfPages = (int)Math.Ceiling(pageCount);
        //    int pageToSkip = (model.pageNumber - 1) * model.itemsPerPage;
        //    pagedData.Data = da.GetUsermail(model.rid).Skip(pageToSkip).Take(model.itemsPerPage).ToList();
        //    return Ok(pagedData);
        //}
        [Route("MailDetails")]
        public IHttpActionResult PostMailDetails(MailDes mailDes)
        {
            UserInbox data = da.GetUsermailDetails(mailDes);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("DraftDetails")]
        public IHttpActionResult PostDraftDetails(MailDes mailDes)
        {
            UserInbox data = da.GetUserDraftDetails(mailDes);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("Attachments")]
        public IHttpActionResult PostAttachments(MailDes mailDes)
        {

            List<AttachmentModel> data = da.Getattachments(mailDes).Where(k => k.AttachmentType == "C").ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("SentAttachments")]
        public IHttpActionResult PostSentAttachments(MailDes mailDes)
        {

            List<AttachmentModel> data = da.GetSentattachments(mailDes).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("Drafts")]
        public IHttpActionResult PostDraftMail(MailBox mailBox)
        {
            string data = "";
            string msgid = DateTime.Now.ToString("yyMMddHHmmssff");

            data = da.Draftmail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, msgid);
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("FromDraft/{Rid}")]
        public IHttpActionResult GetFromDraft(Int64 Rid)
        {
            List<UserInbox> data = da.GetFromDraft(Rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }


        [Route("MoveToTrash/{SelectedIDs}")]
        public IHttpActionResult GetMoveToTrash(string SelectedIDs)
        {
            String[] spearator = { "[", ",", "]" };
            string[] MailId = SelectedIDs.Split(spearator, 1000000000, StringSplitOptions.RemoveEmptyEntries);
            string data = "";
            foreach (var k in MailId)
            {
                data = da.MoveToTrash(Convert.ToInt64(k));
            }
            if (data == "Success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AllMailMoveToTrash")]
        public IHttpActionResult PostAllMailsMoveToTrash(MoveToArchiveOrtrash moveToTrash)
        {

            string data = da.AllMailMoveToTrash(moveToTrash.Rid, moveToTrash.flag);

            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("FromTrash/{Rid}")]
        public IHttpActionResult GetFromTrash(Int64 Rid)
        {
            List<UserInbox> data = da.GetFromTrash(Rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        //[Route("DeleteFromTrash/{MailId}")]
        //public IHttpActionResult DeleteFromTrash(Int64 MailId)
        //{
        //    string data = "";
        //    data = da.DeleteFromTrash(MailId);
        //    if (data == "Success")
        //    {
        //        return Ok(data);
        //    }
        //    else
        //    {
        //        HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
        //        return Content(HttpStatusCode.BadRequest, myCustomError);
        //    }
        //}

        [Route("MoveToArchive/{SelectedIDs}")]
        public IHttpActionResult GetMoveToArchive(string SelectedIDs)
        {
            String[] spearator = { "[", ",", "]" };
            string[] MailId = SelectedIDs.Split(spearator, 1000000000, StringSplitOptions.RemoveEmptyEntries);
            string data = "";
            foreach (var k in MailId)
            {
                data = da.MoveToArchive(Convert.ToInt64(k));
            }
            if (data == "Success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AllMailMoveToArchive")]
        public IHttpActionResult PostAllMailsMoveToArchive(MoveToArchiveOrtrash moveToArchive)
        {

            string data = da.AllMailMoveToArchive(moveToArchive.Rid, moveToArchive.flag);

            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("FromArchive/{Rid}")]
        public IHttpActionResult GetFromArchive(Int64 Rid)
        {
            List<UserInbox> data = da.GetFromArchive(Rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MovebackToInbox")]
        public IHttpActionResult PostMoveBackToInbox(MoveToInbox moveToInbox)
        {
            string data = da.MovebackToInbox(moveToInbox);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MoveToImportant/{mailId}")]
        public IHttpActionResult GetMoveToImportant(Int64 mailId)
        {
            string data = "";

            data = da.MoveToImportant(mailId);
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AllMailFromImportant/{Rid}")]
        public IHttpActionResult GetAllMailFromImportant(Int64 Rid)
        {

            List<UserInbox> data = da.GetFromImportant(Rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("ForgetPassword/{mobileNo}")]
        public IHttpActionResult GetforgetpassOTP(string mobileNo)
        {
            if (!string.IsNullOrEmpty(mobileNo))
            {
                string OTP = CGeneral.GetRendomNo(6);
                var res = da.ForgetPass(mobileNo, OTP);
                if (res == "success")
                {
                    String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserForgetMsg"]).Replace("[OTP]", OTP);
                    SMSSender.SMSSend(Msg, mobileNo);

                   // displayMessage.Message = "An OTP has been sent to your registered  mobile no. XXXXXX" + mobileNo.Substring(6, 4);
                    //displayMessage.Type = "s";
                    return Ok(new { displayMessage });
                }
                else
                {
                    HttpError myCustomError = new HttpError("The Mobile No. you have entered is not Registered on this Portal. Please enter correct Mobile No.") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Please Enter Mobile Number") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("VerifyOTP")]
        public IHttpActionResult PostVerifyOtp(verifyOTP verifyOTP)
        {
            if (!string.IsNullOrEmpty(verifyOTP.OTP))
            {
                var res = da.VerifyOTP(verifyOTP);
                if (res.Verification == "verified")
                {
                    return Ok(res);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Entered OTP is incorrect. Please enter correct OTP.") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Please Enter OTP") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("ChangePassword")]
        public IHttpActionResult PostChangePass(ChangePassword changePassword)
        {
            if (!string.IsNullOrEmpty(changePassword.Password))
            {
                changePassword.Password = objCom.SingleHashing(changePassword.Password);
                var res = da.ChangePassword(changePassword);
                if (res == "success")
                {
                    return Ok(res);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Password did not change") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Change Password is Required") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("ComposeMailWithAttachment")]
        public IHttpActionResult PostComposeMailWithAttachment()
        {
            var httpRequest = HttpContext.Current.Request;
            int i = 0;
            int cntSuccess = 0;
            var uploadedFileNames = new List<string>();
            HttpResponseMessage response = new HttpResponseMessage();
            MailBox mailBox = new MailBox();
            mailBox.Priority = Convert.ToInt32(httpRequest["Priority"]);
            mailBox.SMS = Convert.ToBoolean(httpRequest["SMS"]);
            mailBox.Subject = httpRequest["Subject"];
            mailBox.Message = httpRequest["Message"];
            mailBox.Sid = Convert.ToInt32(httpRequest["Sid"]);
            string[] rid = httpRequest["Rid"].Split(',');
            string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
            Int64 mailid = 0;
            foreach (var k in rid)
            {
                //mailid = adminContext.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, Convert.ToInt64(k), msgid);
            }
            string msg = "success";
            AttachmentModel attachmentModel = new AttachmentModel();
            string attachmentfile = null;
            foreach (string file in httpRequest.Files)
            {
                var postedFile = httpRequest.Files[i];
                attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                try
                {
                    postedFile.SaveAs(filePath);
                    uploadedFileNames.Add(httpRequest.Files[i].FileName);
                    attachmentModel.Attachment = attachmentfile;
                    attachmentModel.MailId = msgid;
                    attachmentModel.AttachmentType = "C";
                    attachmentModel.ReplyId = mailid;

                    cntSuccess++;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                msg = da.Attachment(attachmentModel);
                i++;
            }
            if (msg == "success")
            {
                if (mailBox.SMS == true)
                {
                    foreach (var k in rid)
                    {
                        String Msg = Convert.ToString("A message has been received on your Message Board of Mandi Parishad. To view message click on " + "http://mboard.otpl.in/#/login");

                        //string mobile = adminContext.LastLoginInfo(Convert.ToInt64(k)).mobileNo;
                        //SMSSender.SMSSend(Msg, mobile);
                    }
                }
                return Ok(msg);
            }
            else
            {
                return BadRequest();
            }
        }
        [Route("SentMails/{Sid}")]
        public IHttpActionResult GetFromSent(Int64 Sid)
        {
            List<UserSentMail> data = da.GetFromSent(Sid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("SentMailDes")]
        public IHttpActionResult PostFromSent(SendMailDes sendMailDes)
        {
            UserSentMail data = da.GetSentmailDes(sendMailDes);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("CheckOldPass")]
        public IHttpActionResult PostCheckOldPass(CheckOldPass checkOldPass)
        {
            checkOldPass.OldPass = objCom.SingleHashing(checkOldPass.OldPass);
            object res = da.CheckOldPass(checkOldPass);
            if (res.ToString() == "1")
            {
                return Ok("success");

            }
            else
            {
                HttpError myCustomError = new HttpError("Current Password is Incorrect") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }

        }

        [Route("MailReply")]
        public IHttpActionResult PostMailReply()
        {
            var httpRequest = HttpContext.Current.Request;
            int i = 0;
            int cntSuccess = 0;
            var uploadedFileNames = new List<string>();
            HttpResponseMessage response = new HttpResponseMessage();
            MailReply mail = new MailReply();
            mail.Sid = Convert.ToInt64(httpRequest["Sid"]);
            mail.Rid = Convert.ToInt64(httpRequest["Rid"]);
            mail.Message = httpRequest["Message"];
            mail.MessageId = httpRequest["MessageId"];
            mail.Priority = Convert.ToInt32(httpRequest["Priority"]);
            mail.Subject = httpRequest["Subject"];

            Int64 ReplyId = da.mailReply(mail);
            string msg = "";
            AttachmentModel attachmentModel = new AttachmentModel();
            string attachmentfile = null;
            foreach (string file in httpRequest.Files)
            {
                var postedFile = httpRequest.Files[i];
                attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                try
                {
                    postedFile.SaveAs(filePath);
                    uploadedFileNames.Add(httpRequest.Files[i].FileName);
                    attachmentModel.Attachment = attachmentfile;
                    attachmentModel.MailId = httpRequest["MessageId"];
                    attachmentModel.AttachmentType = "R";
                    attachmentModel.ReplyId = ReplyId;
                    cntSuccess++;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                msg = da.Attachment(attachmentModel);
                i++;
            }
            if (msg == "success" || ReplyId > 0)
            {
                return Ok("success");
            }
            else
            {
                return BadRequest();
            }
        }
        [Route("ShowMailReply")]
        public IHttpActionResult PostMailReply(MailDes sendMailDes)
        {
            List<ShowReply> data = da.GetmailReplies(sendMailDes);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("Not send") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetAttachmentFile")]
        public HttpResponseMessage PostAttachment(DownloadFile downloadFile)
        {
            if (!string.IsNullOrEmpty(downloadFile.fileName.Trim()))
            {

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
                string filePath = HttpContext.Current.Server.MapPath("~/Attachments/") + downloadFile.fileName.Trim();
                if (!File.Exists(filePath))
                {
                    response.StatusCode = HttpStatusCode.NotFound;
                    response.ReasonPhrase = string.Format("File not found: {0} .", downloadFile.fileName);
                }
                byte[] bytes = File.ReadAllBytes(filePath);
                response.Content = new ByteArrayContent(bytes);
                response.Content.Headers.ContentLength = bytes.LongLength;
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = downloadFile.fileName;
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(MimeMapping.GetMimeMapping(downloadFile.fileName));
                return response;
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }
        }

        [Route("GetMailHead")]
        public IHttpActionResult PostMailHead(MailDes mailDes)
        {
            UserInbox data = da.GetMailHead(mailDes);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("UpdateDraft/{msgId}")]
        public IHttpActionResult GetUpdateDraft(string msgId)
        {
            string data = da.UpdateDraftToDelete(msgId);
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        //****************
        [Route("GetForword")]
        public IHttpActionResult PostForwordMsg(Forword forword)
        {
            GetForword data = da.ForwordGet(forword);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("Forwarmail")]
        public IHttpActionResult PostForwardmailWithAttachment()
        {
            var httpRequest = HttpContext.Current.Request;
            int i = 0;
            int cntSuccess = 0;
            var uploadedFileNames = new List<string>();
            HttpResponseMessage response = new HttpResponseMessage();
            MailBox mailBox = new MailBox();
            mailBox.Priority = Convert.ToInt32(httpRequest["Priority"]);
            mailBox.SMS = Convert.ToBoolean(httpRequest["SMS"]);
            mailBox.Subject = httpRequest["Subject"];
            mailBox.Message = httpRequest["Message"];
            mailBox.Sid = Convert.ToInt32(httpRequest["Sid"]);
            string[] rid = httpRequest["Rid"].Split(',');
            string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
            Int64 mailid = 0;
            foreach (var k in rid)
            {
                //mailid = adminContext.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, Convert.ToInt64(k), msgid);
            }
            string msg = "success";
            AttachmentModel attachmentModel = new AttachmentModel();
            string attachmentfile = null;
            foreach (string file in httpRequest.Files)
            {
                var postedFile = httpRequest.Files[i];
                attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                try
                {
                    postedFile.SaveAs(filePath);
                    uploadedFileNames.Add(httpRequest.Files[i].FileName);
                    attachmentModel.Attachment = attachmentfile;
                    attachmentModel.MailId = msgid;
                    attachmentModel.AttachmentType = "C";
                    attachmentModel.ReplyId = mailid;
                    cntSuccess++;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                msg = da.Attachment(attachmentModel);
                i++;
            }
            if (httpRequest["OldFiles"] != null)
            {
                string[] oldfiles = httpRequest["OldFiles"].Split(',');
                foreach (string item in oldfiles)
                {
                    attachmentModel.Attachment = item;
                    attachmentModel.MailId = msgid;
                    attachmentModel.AttachmentType = "C";
                    attachmentModel.ReplyId = mailid;
                    msg = da.Attachment(attachmentModel);
                }
            }
            if (msg == "success")
            {
                if (mailBox.SMS == true)
                {
                    foreach (var k in rid)
                    {
                        String Msg = Convert.ToString("A message has been received on your Message Board of Mandi Parishad. To view message click on " + "http://mboard.otpl.in/#/login");

                       // string mobile = adminContext.LastLoginInfo(Convert.ToInt64(k)).mobileNo;
                       // SMSSender.SMSSend(Msg, mobile);
                    }
                }
                return Ok(msg);
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
