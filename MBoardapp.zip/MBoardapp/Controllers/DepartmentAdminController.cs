﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml;
using MBoardapp.Filters;
using MBoardapp.Models;
using MBoardapp.Repository;
using SRVTextToImage;

namespace MBoardapp.Controllers
{

    [EnableCors(origins: "*", headers: "*", methods: "*")]

    [RoutePrefix("api")]

    public class DepartmentAdminController : ApiController
    {
        public string con = "";
        //DepartmentAdminContext da = new DepartmentAdminContext();
        Common objCom = new Common();
        DisplayMessage displayMessage = new DisplayMessage();
       // [Route("getEnc/{dptId}")]
        //public IHttpActionResult GetEncString(string dptId)
        //{
        //    string EncStr = EncriptionDecription.Encrypt(dptId.ToString());
        //    displayMessage.result = new { EncStr };
        //    return Content(HttpStatusCode.BadRequest, displayMessage);
        //}

        [Route("DBConfig/{dptId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetDBConfig(string dptId)
        {
            using (SuperAdminContext superAdmin = new SuperAdminContext())
            {

                DbConfig data = superAdmin.DbConfigById(dptId);
                StringBuilder Con = new StringBuilder(@"Data Source=192.168.0.200\MSSQL2008");
                Con.Append(";Initial Catalog=");
                Con.Append(data.DBName);
                Con.Append(";User ID=" + data.UserId + ";Password=" + data.Password);
                //con = Con.ToString();
                con = HttpContext.Current.Session["connStr"].ToString();
                ////string strCon = @"Data Source=192.168.0.200\MSSQL2008;Initial Catalog=" + data.DBName + ";User ID=mandiparishad;Password=mandiparishad@#123;Connect Timeout=200000; pooling='true'; Max Pool Size=200";
                ////updateConfigFile(strCon);
                //// ConfigurationManager.RefreshSection("connectionStrings");
                //ConfigurationManager.ConnectionStrings["DptContext"].ConnectionString = Con.ToString();



                //var obj = superAdmin.DbConfigById(dptId);
                //Connection objConnection = new Connection();
                //if (obj.DBName == "mb1")
                //{
                //    ConStr = objConnection.ConfigurnewConnectionString(obj.Servername, obj.DatabaseName, obj.UserId, obj.Password, "PersonDatabaseEntities").ToString();
                //}
                //else if (obj.DatabaseName == "mb2")
                //{
                //    ConStr = objConnection.ConfigurnewConnectionString(obj.Servername, obj.DatabaseName, obj.UserId, obj.Password, "EmployeeDatabaseEntities").ToString();
                //}
                //// Your Condition to display the data from the desired database  
                //return View(obj);

            }
            return Ok("Connection stablished");
        }
        //private void AddUpdateConnectionString(string name)
        //{
        //    bool isNew = false;
        //    string path = HttpContext.Current.Server.MapPath("~/Web.Config");
        //    XmlDocument doc = new XmlDocument();
        //    doc.Load(path);
        //    XmlNodeList list = doc.DocumentElement.SelectNodes(string.Format("connectionStrings/add[@name='{0}']", name));
        //    XmlNode node;
        //    isNew = list.Count == 0;
        //    if (isNew)
        //    {
        //        node = doc.CreateNode(XmlNodeType.Element, "add", null);
        //        XmlAttribute attribute = doc.CreateAttribute("name");
        //        attribute.Value = name;
        //        node.Attributes.Append(attribute);

        //        attribute = doc.CreateAttribute("connectionString");
        //        attribute.Value = "";
        //        node.Attributes.Append(attribute);

        //        attribute = doc.CreateAttribute("providerName");
        //        attribute.Value = "System.Data.SqlClient";
        //        node.Attributes.Append(attribute);
        //    }
        //    else
        //    {
        //        node = list[0];
        //    }
        //    string conString = node.Attributes["connectionString"].Value;
        //    SqlConnectionStringBuilder conStringBuilder = new SqlConnectionStringBuilder(conString);
        //    conStringBuilder.InitialCatalog = "TestDB";
        //    conStringBuilder.DataSource = "myserver";
        //    conStringBuilder.IntegratedSecurity = false;
        //    conStringBuilder.UserID = "test";
        //    conStringBuilder.Password = "12345";
        //    node.Attributes["connectionString"].Value = conStringBuilder.ConnectionString;
        //    if (isNew)
        //    {
        //        doc.DocumentElement.SelectNodes("connectionStrings")[0].AppendChild(node);
        //    }
        //    doc.Save(path);
        //}
        //public void updateConfigFile(string con)
        //{
        //    XmlDocument XmlDoc = new XmlDocument();
        //    XmlDoc.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
        //    foreach (XmlElement xElement in XmlDoc.DocumentElement)
        //    {
        //        if (xElement.Name == "connectionStrings")
        //        {
        //            xElement.FirstChild.Attributes[2].Value = con;
        //            break;
        //        }
        //    }
        //    XmlDoc.Save(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
        //}

        /// <summary>
        /// Admin Login
        /// </summary>
        /// <remarks>
        /// All Fields Are Required
        /// </remarks>
        /// <returns></returns>
        [HttpPost]
        [Route("AdminLogin")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostAdminLogin(UserLogin loginData)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string capvalue = HttpContext.Current.Application["a"].ToString();
                if (loginData.Captcha == capvalue)
                {
                    AfterUserLogin data = da.UserLogin(loginData.officeName);
                    if (data != null)
                    {
                        string dbpas = objCom.SingleHashing(loginData.Password);
                        if (dbpas == data.password)
                        {
                            displayMessage.response = "Success";
                            displayMessage.error = "";
                            displayMessage.message = "Login successfull";
                            displayMessage.result = new { data.userId, data.officeName };
                            return Ok(displayMessage);
                        }
                        else
                        {
                            displayMessage.response = "Fail";
                            displayMessage.error = "Entered Password is incorrect. Please enter correct password.";
                            displayMessage.message = "";
                            displayMessage.result = new { };
                            return Content(HttpStatusCode.BadRequest, displayMessage);
                        }
                    }
                    else
                    {
                        displayMessage.response = "Fail";
                        displayMessage.error = "Please Enter Valid UserName.";
                        displayMessage.message = "";
                        displayMessage.result = new { };
                        return Content(HttpStatusCode.BadRequest, displayMessage);
                    }
                }
                else
                {
                    displayMessage.response = "Fail";
                    displayMessage.error = "Entered Captcha value is incorrect. Please enter correct Captcha value.";
                    displayMessage.message = "";
                    displayMessage.result = new { };
                    return Content(HttpStatusCode.BadRequest, displayMessage);
                }
            }
        }
        /// <summary>
        /// Last Login
        /// </summary>
        /// <param name="userId">
        /// Submit The Values for user take reference from example value
        /// </param>
        /// <returns></returns>
        [Route("LastLogin/{userId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetLastlogin(Int64 userId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                GetUserProfileInfo data = da.LastLoginInfo(userId);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("UpdateProfile")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostUpdateProfile()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string imageName = "";
                var httpRequest = HttpContext.Current.Request;
                var postedFile = httpRequest.Files["ProfilePic"];
                Int64 UserId = Convert.ToInt64(httpRequest["userId"]);
                string Mobile = httpRequest["mobileNo"];
                if (postedFile != null)
                {
                    imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                    imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/UserProfile/" + imageName);
                    postedFile.SaveAs(filePath);
                }
                GetUserProfileInfo data = da.UpdateProfile(UserId, Mobile, imageName);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GroupMaster")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetGroup()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<GroupMaster> data = da.GetGroupMaster().OrderBy(k => k.groupName).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("AddUpdateGroupMaster")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostGroup(AddUpdateUserMaster groupMasterData)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (ModelState.IsValid)
                {
                    string data = da.AddUpdateGroupName(groupMasterData.transId, groupMasterData.groupName, groupMasterData.userId);
                    if (data == "Success")
                    {
                        return Ok("Success");
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Not Inserted") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Add Group Name First") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("DeleteGroupMaster/{groupId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetdropGroup(int groupId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var data = da.DeleteGroup(groupId);
                if (data.ToString() == "0")
                {
                    return Ok("Success");
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Deleted") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("AddUser")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostNewUser(AddUser userData)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (ModelState.IsValid)
                {
                    var DisplayPassword = CGeneral.GetRendomPassword(8);
                    userData.password = objCom.SingleHashing(DisplayPassword);
                    String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserCredentialsMsg"]).Replace("[ID]", userData.officeName).Replace("[Pass]", DisplayPassword);
                    var data = da.AddUser(userData);
                    if (data.ToString() == "0")
                    {
                        SMSSender.SMSSend(Msg, userData.mobileNo);
                        return Ok("success");
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("User Not Created") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Add Required Field") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("CheckuserOrMobile")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostCheckUserName(ChkUserMobile userorMobile)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                object data = da.CheckUserNameOrMobile(userorMobile);
                if (data.ToString() == "0")
                {
                    return Ok("Success");
                }
                else
                {
                    HttpError myCustomError = new HttpError("Already Exist") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetUsersCount")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostGetUsersCount(int groupId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var data = da.GetUsersCount(groupId);
                if (data.ToString() == "0")

                {
                    return Ok("Success");
                }
                else
                {
                    HttpError myCustomError = new HttpError("You have completed maximum limit of user creation!") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetUserBygroup/{groupId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetUserBygroup(int groupId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var data = da.GetGroupUsers(groupId);
                if (data != null)

                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No User Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetGroupUserForManage/{groupId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetGroupUserForManage(int groupId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var data = da.GetGroupUsersforManage(groupId);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        /// <summary>
        /// Update User Master data
        /// </summary>
        /// <remarks>
        /// All Fields Are Required
        /// </remarks>
        /// <param name="model">
        /// Submit The Values for Update user Records take reference from example value
        /// </param>
        /// <returns></returns>
        [Route("updateUserMaster")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostupdateUserMaster(UpdateuserModel model)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (ModelState.IsValid)
                {
                    string msg = da.updateUserMaster(model);
                    if (msg == "Success")
                    {
                        return Ok(msg);
                    }
                    else if (msg == "Failed")
                    {
                        return Ok(msg);
                    }
                    else
                    {
                        return BadRequest("Faild To update");
                    }
                }
                else
                {
                    return BadRequest("Fill data in Required Fields");
                }
            }
        }
        /// <summary>
        /// Last Login Report
        /// </summary>
        /// <returns></returns>
        [Route("GetLastLogin")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetLastLogin()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<LastLoginModel> data = da.GetlastloginReport();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("CheckGroupName/{groupName}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetChecgroupName([FromUri] string groupName)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var data = da.CheckGroupName(groupName);
                if (data.ToString() == "0")

                {
                    return Ok("Success");
                }
                else
                {
                    HttpError myCustomError = new HttpError("This Group name already exist. Please try with another groupname!") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("SendReceiveStats")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetSendReceiveStats()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<SendAndReceiveModel> data = da.GetSendAndReceiveMsgs();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("UsedUser")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetuseduserList()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UsedUser> data = da.GetUsedUser();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("NotUsedUser")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetNotuseduserList()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UsedUser> data = da.GetNotUsedUser();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("ActiveDeactiveUser")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostActiveDeactiveUser(ActiveDeactive activeDeactive)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                ActiveDeactiveRespnse data = da.ActiveDeactiveUser(activeDeactive);
                String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserDeactivatMsg"]).Replace("[type]", data.type);
                if (data.status == "success")
                {
                    SMSSender.SMSSend(Msg, data.mobileNo);
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetAllOffice")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetAllOffice()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<GetOfficeName> data = da.OfficeName().Where(k => k.officeName != null).OrderBy(k => k.officeName).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("MsgReportByOfficeName/{userId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMsgReportByOfficeName(Int64 userId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<ReportByOfficeName> data = da.ReportByOfficeName(userId).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("MsgReportBySuject/{subject}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMsgReportByOfficeName(string subject)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<ReportByOfficeName> data = da.ReportBysubject(subject).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("MsgReportByDate")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMsgReportByDate(ReportByDate date)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<ReportByOfficeName> data = da.ReportByDate(date).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("Broadcast")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostBroadcast()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string imageName = null;
                string BrodId = DateTime.Now.ToString("yyMMddHHmmssff");
                string data = "";
                var httpRequest = HttpContext.Current.Request;
                BroadCast broadCast = new BroadCast();
                broadCast.BrodId = BrodId;
                broadCast.Sid = Convert.ToInt64(httpRequest["Sid"]);
                broadCast.Subject = httpRequest["Subject"];
                broadCast.Message = httpRequest["Message"];
                broadCast.ClosedDate = httpRequest["ClosedDate"];
                var postedFile = httpRequest.Files["BroadcastPic"];
                if (postedFile != null)
                {
                    imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                    imageName = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/Broadcastpics/" + imageName);
                    postedFile.SaveAs(filePath);
                }
                else
                {
                    imageName = "";
                }

                string[] rid = httpRequest["Rid"].Split(',');
                string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
                foreach (var k in rid)
                {
                    data = da.BroadcastMsg(broadCast.Sid, Convert.ToInt64(k), BrodId, broadCast.Message, broadCast.Subject, imageName, broadCast.ClosedDate);
                }
                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("BroadcastMessage/{rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetBroadcast(Int64 rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<BroadCastMessage> data = da.ViewBroadcastmsg(rid);

                return Ok(data);
            }
            //else
            //{
            //    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
            //    return Content(HttpStatusCode.BadRequest, myCustomError);
            //}
        }
        [Route("MarkBroadcastMessageSeen/{rowid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetBroadcastMessageSeen(Int64 rowid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = da.BroadcastmsgSeen(rowid);
                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("BroadcastReport")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetBroadcastStats()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<BroadCastMessageReport> data = da.BroadcastStats();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetSendMessage")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostGetSendMsg(GetSendMessage message)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<GetSendMessageList> data = da.GetsendMsgList(message).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        //*************
        [Route("InboxMail/{Rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMail(Int64 Rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserInbox> data = da.GetUsermail(Rid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        //[Route("InboxMail")]
        //public IHttpActionResult PostMail(PagedModel model)
        //{
        //    PagedResponse<List<UserInbox>> pagedData = new PagedResponse<List<UserInbox>>();
        //    pagedData.Total = da.GetUsermail(model.rid).Count();
        //    double pageCount = (double)(pagedData.Total / model.itemsPerPage);
        //    pagedData.NumberOfPages = (int)Math.Ceiling(pageCount);
        //    int pageToSkip = (model.pageNumber - 1) * model.itemsPerPage;
        //    pagedData.Data = da.GetUsermail(model.rid).Skip(pageToSkip).Take(model.itemsPerPage).ToList();
        //    return Ok(pagedData);
        //}
        [Route("MailDetails")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMailDetails(MailDes mailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                UserInbox data = da.GetUsermailDetails(mailDes);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("DraftDetails")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostDraftDetails(MailDes mailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                UserInbox data = da.GetUserDraftDetails(mailDes);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("Attachments")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostAttachments(MailDes mailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<AttachmentModel> data = da.Getattachments(mailDes).Where(k => k.AttachmentType == "C").ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("SentAttachments")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostSentAttachments(MailDes mailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<AttachmentModel> data = da.GetSentattachments(mailDes).ToList();
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("Drafts")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostDraftMail(MailBox mailBox)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = "";
                string msgid = DateTime.Now.ToString("yyMMddHHmmssff");

                data = da.Draftmail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, msgid);
                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("FromDraft/{Rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetFromDraft(Int64 Rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserInbox> data = da.GetFromDraft(Rid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }


        [Route("MoveToTrash/{SelectedIDs}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMoveToTrash(string SelectedIDs)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                String[] spearator = { "[", ",", "]" };
                string[] MailId = SelectedIDs.Split(spearator, 1000000000, StringSplitOptions.RemoveEmptyEntries);
                string data = "";
                foreach (var k in MailId)
                {
                    data = da.MoveToTrash(Convert.ToInt64(k));
                }
                if (data == "Success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("AllMailMoveToTrash")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostAllMailsMoveToTrash(MoveToArchiveOrtrash moveToTrash)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = da.AllMailMoveToTrash(moveToTrash.Rid, moveToTrash.flag);

                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("FromTrash/{Rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetFromTrash(Int64 Rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserInbox> data = da.GetFromTrash(Rid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        //[Route("DeleteFromTrash/{MailId}")]
        //public IHttpActionResult DeleteFromTrash(Int64 MailId)
        //{
        //    string data = "";
        //    data = da.DeleteFromTrash(MailId);
        //    if (data == "Success")
        //    {
        //        return Ok(data);
        //    }
        //    else
        //    {
        //        HttpError myCustomError = new HttpError("Not Move To Trash") { { "Type", "w" } };
        //        return Content(HttpStatusCode.BadRequest, myCustomError);
        //    }
        //}

        [Route("MoveToArchive/{SelectedIDs}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMoveToArchive(string SelectedIDs)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                String[] spearator = { "[", ",", "]" };
                string[] MailId = SelectedIDs.Split(spearator, 1000000000, StringSplitOptions.RemoveEmptyEntries);
                string data = "";
                foreach (var k in MailId)
                {
                    data = da.MoveToArchive(Convert.ToInt64(k));
                }
                if (data == "Success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("AllMailMoveToArchive")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostAllMailsMoveToArchive(MoveToArchiveOrtrash moveToArchive)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = da.AllMailMoveToArchive(moveToArchive.Rid, moveToArchive.flag);

                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("FromArchive/{Rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetFromArchive(Int64 Rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserInbox> data = da.GetFromArchive(Rid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("MovebackToInbox")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMoveBackToInbox(MoveToInbox moveToInbox)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = da.MovebackToInbox(moveToInbox);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("MoveToImportant/{mailId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetMoveToImportant(Int64 mailId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = "";

                data = da.MoveToImportant(mailId);
                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not Move To Archive") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("AllMailFromImportant/{Rid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetAllMailFromImportant(Int64 Rid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserInbox> data = da.GetFromImportant(Rid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("ForgetPassword/{mobileNo}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetforgetpassOTP(string mobileNo)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (!string.IsNullOrEmpty(mobileNo))
                {
                    string OTP = CGeneral.GetRendomNo(6);
                    var res = da.ForgetPass(mobileNo, OTP);
                    if (res == "success")
                    {
                        String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserForgetMsg"]).Replace("[OTP]", OTP);
                        SMSSender.SMSSend(Msg, mobileNo);

                        // displayMessage.Message = "An OTP has been sent to your registered  mobile no. XXXXXX" + mobileNo.Substring(6, 4);
                        //displayMessage.Type = "s";
                        return Ok(new { displayMessage });
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("The Mobile No. you have entered is not Registered on this Portal. Please enter correct Mobile No.") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Please Enter Mobile Number") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("VerifyOTP")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostVerifyOtp(verifyOTP verifyOTP)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (!string.IsNullOrEmpty(verifyOTP.OTP))
                {
                    var res = da.VerifyOTP(verifyOTP);
                    if (res.Verification == "verified")
                    {
                        return Ok(res);
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Entered OTP is incorrect. Please enter correct OTP.") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Please Enter OTP") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("ChangePassword")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostChangePass(ChangePassword changePassword)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (!string.IsNullOrEmpty(changePassword.Password))
                {
                    changePassword.Password = objCom.SingleHashing(changePassword.Password);
                    var res = da.ChangePassword(changePassword);
                    if (res == "success")
                    {
                        return Ok(res);
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Password did not change") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Change Password is Required") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("ComposeMailWithAttachment")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostComposeMailWithAttachment()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var httpRequest = HttpContext.Current.Request;
                int i = 0;
                int cntSuccess = 0;
                var uploadedFileNames = new List<string>();
                HttpResponseMessage response = new HttpResponseMessage();
                MailBox mailBox = new MailBox();
                mailBox.Priority = Convert.ToInt32(httpRequest["Priority"]);
                mailBox.SMS = Convert.ToBoolean(httpRequest["SMS"]);
                mailBox.Subject = httpRequest["Subject"];
                mailBox.Message = httpRequest["Message"];
                mailBox.Sid = Convert.ToInt32(httpRequest["Sid"]);
                string[] rid = httpRequest["Rid"].Split(',');
                string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
                Int64 mailid = 0;
                foreach (var k in rid)
                {
                    //mailid = adminContext.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, Convert.ToInt64(k), msgid);
                }
                string msg = "success";
                AttachmentModel attachmentModel = new AttachmentModel();
                string attachmentfile = null;
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files[i];
                    attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                    try
                    {
                        postedFile.SaveAs(filePath);
                        uploadedFileNames.Add(httpRequest.Files[i].FileName);
                        attachmentModel.Attachment = attachmentfile;
                        attachmentModel.MailId = msgid;
                        attachmentModel.AttachmentType = "C";
                        attachmentModel.ReplyId = mailid;

                        cntSuccess++;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    msg = da.Attachment(attachmentModel);
                    i++;
                }
                if (msg == "success")
                {
                    if (mailBox.SMS == true)
                    {
                        foreach (var k in rid)
                        {
                            String Msg = Convert.ToString("A message has been received on your Message Board of Mandi Parishad. To view message click on " + "http://mboard.otpl.in/#/login");

                            //string mobile = adminContext.LastLoginInfo(Convert.ToInt64(k)).mobileNo;
                            //SMSSender.SMSSend(Msg, mobile);
                        }
                    }
                    return Ok(msg);
                }
                else
                {
                    return BadRequest();
                }
            }
        }
        [Route("SentMails/{Sid}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetFromSent(Int64 Sid)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<UserSentMail> data = da.GetFromSent(Sid);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("SentMailDes")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostFromSent(SendMailDes sendMailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                UserSentMail data = da.GetSentmailDes(sendMailDes);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("CheckOldPass")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostCheckOldPass(CheckOldPass checkOldPass)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                checkOldPass.OldPass = objCom.SingleHashing(checkOldPass.OldPass);
                object res = da.CheckOldPass(checkOldPass);
                if (res.ToString() == "1")
                {
                    return Ok("success");

                }
                else
                {
                    HttpError myCustomError = new HttpError("Current Password is Incorrect") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }

        }

        [Route("MailReply")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMailReply()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var httpRequest = HttpContext.Current.Request;
                int i = 0;
                int cntSuccess = 0;
                var uploadedFileNames = new List<string>();
                HttpResponseMessage response = new HttpResponseMessage();
                MailReply mail = new MailReply();
                mail.Sid = Convert.ToInt64(httpRequest["Sid"]);
                mail.Rid = Convert.ToInt64(httpRequest["Rid"]);
                mail.Message = httpRequest["Message"];
                mail.MessageId = httpRequest["MessageId"];
                mail.Priority = Convert.ToInt32(httpRequest["Priority"]);
                mail.Subject = httpRequest["Subject"];

                Int64 ReplyId = da.mailReply(mail);
                string msg = "";
                AttachmentModel attachmentModel = new AttachmentModel();
                string attachmentfile = null;
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files[i];
                    attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                    try
                    {
                        postedFile.SaveAs(filePath);
                        uploadedFileNames.Add(httpRequest.Files[i].FileName);
                        attachmentModel.Attachment = attachmentfile;
                        attachmentModel.MailId = httpRequest["MessageId"];
                        attachmentModel.AttachmentType = "R";
                        attachmentModel.ReplyId = ReplyId;
                        cntSuccess++;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    msg = da.Attachment(attachmentModel);
                    i++;
                }
                if (msg == "success" || ReplyId > 0)
                {
                    return Ok("success");
                }
                else
                {
                    return BadRequest();
                }
            }
        }
        [Route("ShowMailReply")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMailReply(MailDes sendMailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                List<ShowReply> data = da.GetmailReplies(sendMailDes);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("Not send") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("GetAttachmentFile")]
        [FilterConfig.SetConnection]
        public HttpResponseMessage PostAttachment(DownloadFile downloadFile)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                if (!string.IsNullOrEmpty(downloadFile.fileName.Trim()))
                {

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
                    string filePath = HttpContext.Current.Server.MapPath("~/Attachments/") + downloadFile.fileName.Trim();
                    if (!File.Exists(filePath))
                    {
                        response.StatusCode = HttpStatusCode.NotFound;
                        response.ReasonPhrase = string.Format("File not found: {0} .", downloadFile.fileName);
                    }
                    byte[] bytes = File.ReadAllBytes(filePath);
                    response.Content = new ByteArrayContent(bytes);
                    response.Content.Headers.ContentLength = bytes.LongLength;
                    response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                    response.Content.Headers.ContentDisposition.FileName = downloadFile.fileName;
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue(MimeMapping.GetMimeMapping(downloadFile.fileName));
                    return response;
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                }
            }
        }

        [Route("GetMailHead")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostMailHead(MailDes mailDes)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                UserInbox data = da.GetMailHead(mailDes);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        [Route("UpdateDraft/{msgId}")]
        [FilterConfig.SetConnection]
        public IHttpActionResult GetUpdateDraft(string msgId)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                string data = da.UpdateDraftToDelete(msgId);
                if (data == "success")
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }
        //****************
        [Route("GetForword")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostForwordMsg(Forword forword)
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                GetForword data = da.ForwordGet(forword);
                if (data != null)
                {
                    return Ok(data);
                }
                else
                {
                    HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
        }

        [Route("Forwarmail")]
        [FilterConfig.SetConnection]
        public IHttpActionResult PostForwardmailWithAttachment()
        {
            using (DepartmentAdminContext da = new DepartmentAdminContext(con))
            {
                var httpRequest = HttpContext.Current.Request;
                int i = 0;
                int cntSuccess = 0;
                var uploadedFileNames = new List<string>();
                HttpResponseMessage response = new HttpResponseMessage();
                MailBox mailBox = new MailBox();
                mailBox.Priority = Convert.ToInt32(httpRequest["Priority"]);
                mailBox.SMS = Convert.ToBoolean(httpRequest["SMS"]);
                mailBox.Subject = httpRequest["Subject"];
                mailBox.Message = httpRequest["Message"];
                mailBox.Sid = Convert.ToInt32(httpRequest["Sid"]);
                string[] rid = httpRequest["Rid"].Split(',');
                string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
                Int64 mailid = 0;
                foreach (var k in rid)
                {
                    //mailid = adminContext.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, Convert.ToInt64(k), msgid);
                }
                string msg = "success";
                AttachmentModel attachmentModel = new AttachmentModel();
                string attachmentfile = null;
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files[i];
                    attachmentfile = "mboard" + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
                    var filePath = HttpContext.Current.Server.MapPath("~/Attachments/" + attachmentfile);
                    try
                    {
                        postedFile.SaveAs(filePath);
                        uploadedFileNames.Add(httpRequest.Files[i].FileName);
                        attachmentModel.Attachment = attachmentfile;
                        attachmentModel.MailId = msgid;
                        attachmentModel.AttachmentType = "C";
                        attachmentModel.ReplyId = mailid;
                        cntSuccess++;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    msg = da.Attachment(attachmentModel);
                    i++;
                }
                if (httpRequest["OldFiles"] != null)
                {
                    string[] oldfiles = httpRequest["OldFiles"].Split(',');
                    foreach (string item in oldfiles)
                    {
                        attachmentModel.Attachment = item;
                        attachmentModel.MailId = msgid;
                        attachmentModel.AttachmentType = "C";
                        attachmentModel.ReplyId = mailid;
                        msg = da.Attachment(attachmentModel);
                    }
                }
                if (msg == "success")
                {
                    if (mailBox.SMS == true)
                    {
                        foreach (var k in rid)
                        {
                            String Msg = Convert.ToString("A message has been received on your Message Board of Mandi Parishad. To view message click on " + "http://mboard.otpl.in/#/login");

                            // string mobile = adminContext.LastLoginInfo(Convert.ToInt64(k)).mobileNo;
                            // SMSSender.SMSSend(Msg, mobile);
                        }
                    }
                    return Ok(msg);
                }
                else
                {
                    return BadRequest();
                }
            }
        }

    }
}
