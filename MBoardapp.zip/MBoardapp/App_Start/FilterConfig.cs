﻿using MBoardapp.Models;
using MBoardapp.Repository;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Mvc;

namespace MBoardapp
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
           
        }
        public class SetConnectionAttribute : System.Web.Http.Filters.ActionFilterAttribute
        {
            public override void OnActionExecuting(HttpActionContext actionContext)
            {
                HttpContext ctx = HttpContext.Current;
                string Dept_key = ctx.Request.Headers["Dept_key"].ToString();
                using (SuperAdminContext superAdmin = new SuperAdminContext())
                {
                    string dptId = ctx.Request.Headers["Dept_key"].ToString();
                    DbConfig data = superAdmin.DbConfigById(dptId);
                    StringBuilder Con = new StringBuilder(@"Data Source=192.168.0.200\MSSQL2008");
                    Con.Append(";Initial Catalog=");
                    Con.Append(data.DBName);
                    Con.Append(";User ID=" + data.UserId + ";Password=" + data.Password);
                    
                    ctx.Session["connStr"] = Con.ToString();
                    

                }
            }

         
        }
        //public class SetConnectionAttribute : System.Web.Mvc.ActionFilterAttribute
        //{
        //    public override void OnActionExecuting(ActionExecutingContext filterContext)
        //    {
        //        HttpContext ctx = HttpContext.Current;
        //        using (SuperAdminContext superAdmin = new SuperAdminContext())
        //        {
        //            string dptId = ctx.Request.Headers["Dept_key"].ToString();
        //            DbConfig data = superAdmin.DbConfigById(dptId);
        //            StringBuilder Con = new StringBuilder("Data Source=");
        //            Con.Append(@data.ServerIP);
        //            Con.Append(";Initial Catalog=");
        //            Con.Append(data.DBName);
        //            Con.Append(";User ID=" + data.UserId + ";Password=" + data.Password);

        //        }
        //            base.OnActionExecuting(filterContext);
        //    }
        //}
    }
}
