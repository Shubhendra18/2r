﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SessionManager
/// </summary>
public class SessionManager
{
    public  string cap
    {
        get
        {
            if (HttpContext.Current.Session["cap"] != null)
            {
                return HttpContext.Current.Session["cap"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["cap"] = value;
        }
    }
    public string DeptId
    {
        get
        {
            if (HttpContext.Current.Session["DeptId"] != null)
            {
                return HttpContext.Current.Session["DeptId"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["DeptId"] = value;
        }
    }

    private string _cv;
    public string cv
    {
        get
        {
            return this._cv;
        }
        set
        {
            this._cv = value;
        }
    }




} 