﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MBoardapp.Filters;
using MBoardapp.Models;
using System.Configuration;

namespace MBoardapp.Repository
{

    public partial class DepartmentAdminContext : DbContext
    {

        SqlConnection con = null;
        public DepartmentAdminContext(string Con) : base(Con = HttpContext.Current.Session["connStr"].ToString())
        {
            


        }
        public List<UserList> UserListData()
        {
            var sqlQuery = @"Sp_UserList";
            var res = this.Database.SqlQuery<UserList>(sqlQuery).ToList();
            return res;
        }
        public List<GroupMaster> GetGroupMaster()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@grpID",Value=0},
                new SqlParameter {ParameterName="@gpName",Value=""},
                 };
            var sqlQuery = @"sp_getGroups @grpID,@gpName";
            var res = this.Database.SqlQuery<GroupMaster>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public AfterUserLogin UserLogin(string UserName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=UserName},
                new SqlParameter {ParameterName="@LastLoginIP",Value=Common.GetIPAddress()},

                 };
            var sqlQuery = @"sp_newAdminLogin @userName,@LastLoginIP";
            var res = this.Database.SqlQuery<AfterUserLogin>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo LastLoginInfo(Int64 userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                 };
            var sqlQuery = @"Sp_NewLastUserLoginInfo @userId";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo UpdateProfile(Int64 userId, string mobileNo, string Profilepic)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                new SqlParameter {ParameterName="@mobileNo",Value=mobileNo},
                new SqlParameter {ParameterName="@profilepic",Value=Profilepic},
                 };
            var sqlQuery = @"Sp_NewUpdateProfileInfo @userId,@mobileNo,@profilepic";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AddUpdateGroupName(int transId, String GroupName, int UserId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=transId},
                new SqlParameter {ParameterName="@groupName",Value=GroupName},
                new SqlParameter {ParameterName="@userId",Value=UserId},
                 };
            var sqlQuery = @"sp_saveUpdateGroup @transId,@groupName,@userId";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public object DeleteGroup(int groupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=groupId},
                 };
            var sqlQuery = @"sp_deleteGroup @transId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object AddUser(AddUser addUser)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@NAME_OF_OFFICES",Value=addUser.officeName},
                new SqlParameter {ParameterName="@PASSWORD1",Value=addUser.password},
                new SqlParameter {ParameterName="@groupID",Value=addUser.groupID},
                new SqlParameter {ParameterName="@recflag",Value="A"},
                new SqlParameter {ParameterName="@mobileNo",Value=addUser.mobileNo},
                new SqlParameter {ParameterName="@maxFileSize",Value=addUser.maxFileSize},
                 };
            var sqlQuery = @"Sp_NewAddUserMaster @NAME_OF_OFFICES,@PASSWORD1,@groupID,@recflag,@mobileNo,@maxFileSize";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object GetUsersCount(int GroupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=GroupId}
                 };
            var sqlQuery = @"Proc_selectUserCount @groupID";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object CheckUserNameOrMobile(ChkUserMobile chkUserMobile)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userOrMobile",Value=chkUserMobile.UserorMobile},
                new SqlParameter {ParameterName="@flag",Value=chkUserMobile.flag}
                 };
            var sqlQuery = @"SP_NewgetUserNameOrMobile @userOrMobile,@flag";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<UserByGroup> GetGroupUsers(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Proc_selectUser @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public Int64 ComposeMail(int Priority, bool? SMS, string Subject, string Message, Int64 Sid, Int64 Rid, string msgid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=Priority},
                new SqlParameter {ParameterName="@sms",Value=SMS} ,
                new SqlParameter {ParameterName="@sub",Value=Subject} ,
                new SqlParameter {ParameterName="@msg",Value=Message},
                new SqlParameter {ParameterName="@sid",Value=Sid},
                new SqlParameter {ParameterName="@rid",Value=Rid},
                new SqlParameter {ParameterName="@messageid",Value=msgid}

                 };
            var sqlQuery = @"Sp_NewComposeMail @priority,@sms,@sub,@msg,@sid,@rid,@messageid";
            Int64 res = this.Database.SqlQuery<Int64>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserByGroup> GetGroupUsersforManage(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Sp_NewselectUserByGroupForManage @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string updateUserMaster(UpdateuserModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=model.userId},
                new SqlParameter {ParameterName="@userName",Value=model.officeName},
                new SqlParameter {ParameterName="@mobileNo",Value=model.mobileNo},
                new SqlParameter {ParameterName="@maxFileSize",Value=model.maxFileSize},
                 };
            var sqlQuery = @"Sp_NewupdateUserMaster @userId,@userName,@mobileNo,@maxFileSize";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<LastLoginModel> GetlastloginReport()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=0}
                 };
            var sqlQuery = @"sp_NewgetLastLoginReport @groupID";
            var res = this.Database.SqlQuery<LastLoginModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public object CheckGroupName(String groupName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupName",Value=groupName}
                 };
            var sqlQuery = @"Sp_NewgetGroupName @groupName";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<SendAndReceiveModel> GetSendAndReceiveMsgs()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"sp_NewgetSentAndReceivedStats @groupId";
            var res = this.Database.SqlQuery<SendAndReceiveModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewuserUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetNotUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewNotUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetPostedMessageRecord(int postedid, int searchType, String searchCriteria, DateTime fromDate, DateTime toDate)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@postedid",Value=postedid},
                new SqlParameter {ParameterName="@searchType",Value=searchType},
                new SqlParameter {ParameterName="@searchCriteria",Value=searchCriteria},
                new SqlParameter {ParameterName="@fromDate",Value=fromDate},
                new SqlParameter {ParameterName="@toDate",Value=toDate},
                 };
            var sqlQuery = @"sp_getPostedMessageRecord @postedid,@searchType,@searchCriteria,@fromDate,@toDate";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public ActiveDeactiveRespnse ActiveDeactiveUser(ActiveDeactive activeDeactive)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=activeDeactive.userId},
                new SqlParameter {ParameterName="@recflag",Value=activeDeactive.recflag}
                 };
            var sqlQuery = @"sp_NewActivateDeactivate @userId,@recflag";
            ActiveDeactiveRespnse res = this.Database.SqlQuery<ActiveDeactiveRespnse>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<GetOfficeName> OfficeName()
        {
            var sqlQuery = @"Proc_selectOffice";
            var res = this.Database.SqlQuery<GetOfficeName>(sqlQuery).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportByOfficeName(Int64 userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                 };
            var sqlQuery = @"Sp_NewMessageReport @userId";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportBysubject(string subject)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@subject",Value=subject},
                 };
            var sqlQuery = @"Sp_NewMessageReportbySubject @subject";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportByDate(ReportByDate date)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sdate",Value=date.sdate},
                new SqlParameter {ParameterName="@edate",Value=date.edate},
                 };
            var sqlQuery = @"Sp_NewMessageReportbyDate @sdate,@edate";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string BroadcastMsg(Int64 sid, Int64 rid, string broadid, string message, string sub, string pic, string closedDate)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=sid},
                new SqlParameter {ParameterName="@rid",Value=rid},
                new SqlParameter {ParameterName="@broadid",Value=broadid},
                new SqlParameter {ParameterName="@msg",Value=message},
                new SqlParameter {ParameterName="@sub",Value=sub},
                new SqlParameter {ParameterName="@pic",Value=pic},
                new SqlParameter {ParameterName="@closedate",Value=closedDate}



                 };
            var sqlQuery = @"Sp_NewSendBroadCast @sid,@rid,@broadid,@msg,@sub,@pic,@closedate";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<BroadCastMessage> ViewBroadcastmsg(Int64 rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=rid}
                 };
            var sqlQuery = @"Sp_NewGetBroadcastMessage @rid";
            var res = this.Database.SqlQuery<BroadCastMessage>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string BroadcastmsgSeen(Int64 rowid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rowid",Value=rowid}
                 };
            var sqlQuery = @"Sp_NewBroadcastSeen @rowid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<BroadCastMessageReport> BroadcastStats()
        {
            var sqlQuery = @"Sp_NewViewBroadcastStats";
            var res = this.Database.SqlQuery<BroadCastMessageReport>(sqlQuery).ToList();
            return res;
        }
        public List<GetSendMessageList> GetsendMsgList(GetSendMessage message)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userid",Value=message.userId},
                new SqlParameter {ParameterName="@flag",Value=message.flag}
                 };
            var sqlQuery = @"Sp_NewGetSentMessage @userid,@flag";
            var res = this.Database.SqlQuery<GetSendMessageList>(sqlQuery, sqlParam).ToList();
            return res;
        }



        //******
        public List<UserInbox> GetUsermail(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@Rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewInboxMail @Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserInbox GetUsermailDetails(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@msgid",Value=mailDes.MsgId },
                new SqlParameter {ParameterName="@rid",Value=mailDes.Rid }


                 };
            var sqlQuery = @"Sp_NewMailDes @mailid,@msgid,@rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public UserInbox GetUserDraftDetails(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_draftDes @msgId,@Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<AttachmentModel> Getattachments(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_Newgetattachment @msgId,@Rid";
            List<AttachmentModel> res = this.Database.SqlQuery<AttachmentModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<AttachmentModel> GetSentattachments(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_NewgetSentattachment @msgId,@Rid";
            List<AttachmentModel> res = this.Database.SqlQuery<AttachmentModel>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string DeleteFromTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewDeleteFromTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        //**********************Has to be update later
        public string Draftmail(int Priority, bool? SMS, string Subject, string Message, Int64 Sid, string msgid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=Priority},
                new SqlParameter {ParameterName="@sms",Value=SMS} ,
                new SqlParameter {ParameterName="@sub",Value=Subject} ,
                new SqlParameter {ParameterName="@msg",Value=Message},
                new SqlParameter {ParameterName="@sid",Value=Sid},
                new SqlParameter {ParameterName="@messageid",Value=msgid}
                 };
            var sqlQuery = @"Sp_NewDraftMail @priority,@sms,@sub,@msg,@sid,@messageid";
            string res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromDraft(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetAllFromDraft @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MoveToTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToTrash(Int64 Rid, int flag)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid},
                 new SqlParameter {ParameterName="@flag",Value=flag}
                 };
            var sqlQuery = @"Sp_NewAllMailToTrash @rid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromTrash(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewMailStoredInTrash @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MoveToArchive(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoArchive @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToArchive(Int64 Rid, int flag)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid},
                new SqlParameter {ParameterName="@flag",Value=flag},
                 };
            var sqlQuery = @"Sp_NewSendAllMailToArchive @rid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromArchive(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetMailStoredInArchive @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MovebackToInbox(MoveToInbox moveTo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=moveTo.mailId},
                new SqlParameter {ParameterName="@flag",Value=moveTo.flag}
                 };
            var sqlQuery = @"Sp_NewSendBackToInbox @mailid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string MoveToImportant(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewAddToImportant @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromImportant(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetAllFromImportant @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string ForgetPass(string mobile, string OTP)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mobile",Value=mobile},
                new SqlParameter {ParameterName="@Otp",Value=OTP},
                 };
            var sqlQuery = @"Sp_NewGetUserMobileUpdateOtp @mobile,@Otp";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public AfterverifyOTP VerifyOTP(verifyOTP verifyOTP)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mobile",Value=verifyOTP.mobileNo},
                new SqlParameter {ParameterName="@OTP",Value=verifyOTP.OTP},
                 };
            var sqlQuery = @"Sp_NewVerifyUserMobile @OTP,@mobile";
            var res = this.Database.SqlQuery<AfterverifyOTP>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string ChangePassword(ChangePassword changePassword)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=changePassword.userId},
                new SqlParameter {ParameterName="@Password",Value=changePassword.Password},
                 };
            var sqlQuery = @"Sp_NewChangeUserPass @userId,@Password";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string Attachment(AttachmentModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=model.MailId},
                new SqlParameter {ParameterName="@attachment",Value=model.Attachment},
                new SqlParameter {ParameterName="@type",Value=model.AttachmentType},
                new SqlParameter {ParameterName="@replyid",Value=model.ReplyId},
                 };
            var sqlQuery = @"Sp_NewAttachments @mailid,@attachment,@replyid,@type";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserSentMail> GetFromSent(Int64 Sid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=Sid}
                 };
            var sqlQuery = @"Sp_NewGetSentMails @sid";
            var res = this.Database.SqlQuery<UserSentMail>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserSentMail GetSentmailDes(SendMailDes sendMailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=sendMailDes.userId},
                new SqlParameter {ParameterName="@messageid",Value=sendMailDes.MessageId}

                 };
            var sqlQuery = @"Sp_NewGetSentMailsDes @sid,@messageid";
            var res = this.Database.SqlQuery<UserSentMail>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        public object CheckOldPass(CheckOldPass checkOldPass)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=checkOldPass.userId},
                new SqlParameter {ParameterName="@oldpass",Value=checkOldPass.OldPass},
                 };
            var sqlQuery = @"Sp_NewCheckOldPassword @userId,@oldpass";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public Int64 mailReply(MailReply mailReply)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=mailReply.Sid},
                new SqlParameter {ParameterName="@rid",Value=mailReply.Rid},
                new SqlParameter {ParameterName="@messageid",Value=mailReply.MessageId},
                new SqlParameter {ParameterName="@msg",Value=mailReply.Message},
                new SqlParameter {ParameterName="@priority",Value=mailReply.Priority},
                new SqlParameter {ParameterName="@sub",Value=mailReply.Subject}

                 };
            var sqlQuery = @"Sp_NewSendReply @sid,@rid,@messageid,@msg,@priority,@sub";
            var res = this.Database.SqlQuery<Int64>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<ShowReply> GetmailReplies(MailDes sendMailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailId",Value=sendMailDes.MailId},
                new SqlParameter {ParameterName="@msgId",Value=sendMailDes.MsgId},
                new SqlParameter {ParameterName="@sid",Value=sendMailDes.Rid},
                 };
            var sqlQuery = @"Sp_NewgetAllReply @mailId,@msgId,@sid";
            var res = this.Database.SqlQuery<ShowReply>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserInbox GetMailHead(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@msgid",Value=mailDes.MsgId },
                new SqlParameter {ParameterName="@rid",Value=mailDes.Rid }
                 };
            var sqlQuery = @"Sp_NewMailHead @mailid,@msgid,@rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string UpdateDraftToDelete(string msgId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgid",Value=msgId}
                 };
            var sqlQuery = @"Sp_NewUpdateDraft @msgid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        //**************Forword
        public GetForword ForwordGet(Forword forword)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=forword.mailId},
                new SqlParameter {ParameterName="@rid",Value=forword.rid}
                 };
            var sqlQuery = @"Sp_NewForwordMailDes @mailid,@rid";
            var res = this.Database.SqlQuery<GetForword>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
    }
}