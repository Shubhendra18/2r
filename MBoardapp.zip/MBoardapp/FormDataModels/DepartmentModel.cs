﻿using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Description;

namespace MBoardapp.FormDataModels
{
    public class DepartmentModel : IOperationFilter
    {
        [AttributeUsage(AttributeTargets.Method)]
        public sealed class SwaggerFormAttribute : Attribute
        {
            public SwaggerFormAttribute()
            {

            }
        }
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            var requestAttributes = apiDescription.GetControllerAndActionAttributes<SwaggerFormAttribute>();
            foreach (var attr in requestAttributes)
            {
                operation.parameters = new[]
                {
                    new Parameter{ name = "DepartmentName", @in  = "formData",description = "Department Name",required = true,type = "string"},
                    new Parameter{ name = "Title", @in  = "formData",description = "Department Title or Tag Line",required = true,type = "string"},
                    new Parameter { name ="Address",@in = "formData",description = "Address of Department",required = true,type = "string"},
                    new Parameter { name ="Email",@in = "formData",description = "Email",required = true,type = "string"},
                    new Parameter{ name = "Mobile", @in  = "formData",description = "Mobile Number",required = true,type = "string"},
                    new Parameter{ name = "Logo", @in  = "formData",description = "Department Logo",required = true,type = "file"},
                };
                operation.consumes.Add("multipart/form-data");
            }
        }
    }
}