﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MBoardapp.Models
{

    public class AttachmentModel
    {
        public Int64 RowId { get; set; }
        public string Attachment { get; set; }
        public string MailId { get; set; }
        public string AttachmentType { get; set; }
        public Int64 ReplyId { get; set; } = 0;
    }
    public class UserInbox
    {
        public Int64 MailId { get; set; }
        public int Priority { get; set; }
        public bool? SMS { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime PostDate { get; set; }
        public Int64 Rid { get; set; }
        public Int64 userId { get; set; }
        public string officeName { get; set; }
        public string Receiver { get; set; }
        public bool? IsImportant { get; set; }
        public string ProfilePic { get; set; }
        public string MessageID { get; set; }
        public bool? IsViewed { get; set; }
        public string MailType { get; set; }
        public string Attachment { get; set; }



    }
    public class MailDes
    {
        public Int64 MailId { get; set; }
        public string MsgId { get; set; }
        public Int64 Rid { get; set; }


    }
    public class UpdateuserModel
    {
        [Required]
        public string officeName { get; set; }
        [Required]
        public Int64 userId { get; set; }
        [Required]
        public string mobileNo { get; set; }
        public string maxFileSize { get; set; }


    }
    public class UserId
    {
        public Int64 Rid { get; set; }
    }
    public class MoveToInbox
    {
        public Int64 mailId { get; set; }
        public int flag { get; set; }

    }
    public class verifyOTP
    {
        public string mobileNo { get; set; }
        public string OTP { get; set; }

    }
    public class AfterverifyOTP
    {
        public Int64 userId { get; set; }
        public string Verification { get; set; }

    }
    public class ChangePassword
    {
        public Int64 userId { get; set; }
        public string Password { get; set; }

    }
    public class CheckOldPass
    {
        public Int64 userId { get; set; }
        public string OldPass { get; set; }
    }
    public class GetUserProfileInfo
    {
        public Int64 userId { get; set; }
        public string officeName { get; set; }
        public string mobileNo { get; set; }
        public DateTime LastLogin { get; set; }
        public string ProfilePic { get; set; }
    }
    public class UserSentMail
    {
        public string MessageID { get; set; }
        public int Priority { get; set; }
        public bool? SMS { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime PostDate { get; set; }
        public string PostTime { get; set; }
        public string UserName { get; set; }

    }
    public class SendMailDes
    {
        public Int64 userId { get; set; }
        public string MessageId { get; set; }
    }

    public class MailReply
    {
        public string MessageId { get; set; }
        public Int64 Sid { get; set; }
        public Int64 Rid { get; set; }
        public string Message { get; set; }
        public int Priority { get; set; }
        public string Subject { get; set; }


    }
    public class ShowReply
    {
        public Int64 RowId { get; set; }
        public string Message { get; set; }
        public string MessageId { get; set; }
        public DateTime Postdate { get; set; }
        public string officeName { get; set; }
        public string Receiver { get; set; }
        public string ProfilePic { get; set; }
        public string Attachment { get; set; }
        public Int64 MailId { get; set; }


    }
    public class DownloadFile
    {
        public string fileName { get; set; }
    }
    public class MoveToArchiveOrtrash
    {
        public Int64 Rid { get; set; }
        public int flag { get; set; }
    }
    public class PagedResponse<T>
    {
        public int Total { get; set; }
        public int NumberOfPages { get; set; }
        public T Data { get; set; }
    }
    public class PagedModel
    {
        public int pageNumber { get; set; }
        public int itemsPerPage { get; set; }
        public Int64 rid { get; set; }

    }

    public class ComposeResponse
    {
        public string MessageID { get; set; }
        public Int64 MailId { get; set; }
    }
    public class MovetoTrash
    {
        public Int64[] mailId { get; set; }
    }

    //*****
    public class Forword
    {
        public Int64 mailId { get; set; }
        public Int64 rid { get; set; }

    }
    public class GetForword
    {
        public Int64 MailId { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public string MessageID { get; set; }
        public string Attachment { get; set; }


    }
}